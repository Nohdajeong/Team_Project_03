#pragma once
#include "Obj.h"
class CMonster : public CObj
{
public:
	CMonster();
	virtual ~CMonster();

public:	
	virtual void Initialize() override;
	virtual void Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

public:
	void		Set_Player(CObj* pPlayer) { m_pPlayer = pPlayer; }

public:
	CObj*		m_pPlayer;
};

