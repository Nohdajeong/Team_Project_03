#pragma once
#include "Obj.h"
class CTank :
    public CObj
{
public:
             CTank();
    virtual ~CTank();

public:
    virtual void Initialize() override;
    virtual void Update() override;
    virtual void Render(HDC hDC) override;
    virtual void Release() override;

private:
    D3DXVECTOR3 vLeftTop;
    D3DXVECTOR3 vRightTop;
    D3DXVECTOR3 vLeftBottom;
    D3DXVECTOR3 vRightBottom;
    
    float   m_fAngle;
    float   m_fPosinAngle;
    float   m_fPosinDistance;

    D3DXMATRIX matScale, matRotate, matMove;
    D3DXVECTOR3 m_tPosin;
    D3DXMATRIX  matPosinRotate;
};

