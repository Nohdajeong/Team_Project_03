#pragma once

#include "Define.h"
#include "Player.h"
#include "Monster.h"
#include "Tank.h"

class CMainGame
{

public:
	CMainGame();
	~CMainGame();
public:
	void		Initialize(void);
	void		Update(void);
	void		Render(void);
	void		Release(void);

private:
	CObj*			m_pPlayer;
	CObj*			m_pMonster;
	CObj*			m_pTank;

	HDC			m_DC;
};

