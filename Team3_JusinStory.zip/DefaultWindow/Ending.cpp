#include "stdafx.h"
#include "Ending.h"

CEnding::CEnding()
{
}

CEnding::~CEnding()
{
}

void CEnding::Initialize()
{
}

void CEnding::Update()
{
}

void CEnding::Late_Update()
{
}

void CEnding::Render(HDC hDC)
{
}

void CEnding::Release()
{
}
