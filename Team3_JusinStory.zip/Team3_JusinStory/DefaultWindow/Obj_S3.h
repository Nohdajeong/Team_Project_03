#pragma once
#include "Define.h"

class CObj_S3
{
public:
	CObj_S3();
	virtual ~CObj_S3();

public:
	const INFO& Get_Info() const { return m_tInfo; }
	RENDERID		Get_RenderID() { return m_eRender; }
	void			Set_Pos(float _fX, float _fY)
	{
		m_tInfo.vPos.x = _fX;
		m_tInfo.vPos.y = _fY;
	}
	bool		Get_Awake() { return m_bAwake; }
	void		Set_Awake(bool _bAwake) { m_bAwake = _bAwake; }

public:
	virtual void		Initialize()	PURE;
	virtual int			Update()		PURE;
	virtual void		Late_Update()	PURE;
	virtual void		Render(HDC hDC)	PURE;
	virtual void		Release()		PURE;

protected:
	void		Move_Frame();

protected:
	INFO		m_tInfo;
	float		m_fSpeed;
	FRAME		m_tFrame;
	RENDERID	m_eRender;
	bool		m_bAwake;
	bool		m_bDead;

	TCHAR* m_pFrameKey;

};

