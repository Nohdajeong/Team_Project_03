#include "stdafx.h"
#include "S4_Player.h"
#include "KeyMgr.h"
#include "BmpMgr.h"

S4_Player::S4_Player(): 
	m_ePreState(STATE_END), m_eCurState(IDLE)
	,UpKey(false),DownKey(false),LeftKey(false),RightKey(false)
{
}

S4_Player::~S4_Player()
{
	Release();
}

void S4_Player::Initialize()
{
	CBmpMgr::Get_Instance()->Insert_Bmp(L"../Image/Teacher.bmp", L"Teacher");

	m_tInfo.vPos = { 400.f ,300.f, 0.f };
	m_fSpeed = 5.f;
	m_fAngle = 0.f;

	m_fScaleX = 50.f;
	m_fScaleY = 75.f;

	m_tInfo.vDir = { 0.0f, 0.1f, 0.0f };

	m_pFrameKey = L"PLAYER_UP";

	m_tFrame.iFrameStart = 0;
	m_tFrame.iFrameEnd = 2;
	m_tFrame.iMotion = 3;
	m_tFrame.dwTime = GetTickCount();
	m_tFrame.dwSpeed = 100;

	m_eRender = GAMEOBJECT;

	m_tOriginPos = m_tInfo.vPos;

	m_tInfo.vColliderpos.x = m_tInfo.vPos.x;
	m_tInfo.vColliderpos.y = m_tInfo.vPos.y + 30;
	m_tInfo.vColliderOriginPos = m_tInfo.vColliderpos;


	m_tInfo.fWidth	=	40.f;
	m_tInfo.fHeight =	20.f;
	
	
}

int S4_Player::Update()
{
	SetRectPoint(m_tInfo, m_tInfo.fWidth, m_tInfo.fHeight);

	KeyInput();
	
	D3DXMATRIX          matColiderScale, matColliderRotZ, matColiderTrans;

	D3DXMatrixScaling(&matColiderScale, 2.5f, 0.8f, 0.f);
	D3DXMatrixRotationZ(&matColliderRotZ, m_fAngle);
	D3DXMatrixTranslation(&matColiderTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);
	ColliderMat = matColiderScale * matColliderRotZ * matColiderTrans;
	
	m_tInfo.vColliderpos = m_tInfo.vColliderOriginPos;
	m_tInfo.vColliderpos -= { 400.f, 300.f, 0.f};

	D3DXVec3TransformCoord(&m_tInfo.vColliderpos, &m_tInfo.vColliderpos, &ColliderMat);
	
	return OBJ_NOEVENT;
}

void S4_Player::Late_Update()
{
}

void S4_Player::Render(HDC hDC)
{
	HDC	hMemDC = CBmpMgr::Get_Instance()->Find_Img(L"Teacher");

	m_tInfo.vDir = Get_Dir(UpKey, LeftKey, DownKey, RightKey);

	MoveToEx(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y, nullptr);
	
	LineTo(hDC, m_tInfo.vPoint[1].x, m_tInfo.vPoint[1].y);
	LineTo(hDC, m_tInfo.vPoint[2].x, m_tInfo.vPoint[2].y);
	LineTo(hDC, m_tInfo.vPoint[3].x, m_tInfo.vPoint[3].y);
	LineTo(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y);


	GdiTransparentBlt(hDC, m_tInfo.vPos.x - m_fScaleX / 2, m_tInfo.vPos.y - m_fScaleY / 2, m_fScaleX, m_fScaleY, hMemDC, m_tFrame.iFrameStart * m_fScaleX, m_tFrame.iMotion * m_fScaleY, m_fScaleX, m_fScaleY, RGB(195, 134, 255));

}

void S4_Player::Release()
{
}

void S4_Player::Motion_Change()
{
	if (m_ePreState != m_eCurState)
	{
		switch (m_eCurState)
		{
		case IDLE:
			m_tFrame.iFrameStart = 0;
			m_tFrame.iFrameEnd = 3;
			m_tFrame.iMotion = 0;
			m_tFrame.dwSpeed = 200;
			m_tFrame.dwTime = GetTickCount();
			break;

		case WALK:
			if (m_pFrameKey == L"PLAYER_LEFT")
			{
				m_tFrame.iFrameStart = 0;
				m_tFrame.iFrameEnd = 2;
				m_tFrame.iMotion = 1;
				m_tFrame.dwSpeed = 100;
				m_tFrame.dwTime = GetTickCount();
			}

			else if (m_pFrameKey == L"PLAYER_RIGHT")
			{
				m_tFrame.iFrameStart = 0;
				m_tFrame.iFrameEnd = 2;
				m_tFrame.iMotion = 2;
				m_tFrame.dwSpeed = 100;
				m_tFrame.dwTime = GetTickCount();
			}

			else if (m_pFrameKey == L"PLAYER_UP")
			{
				m_tFrame.iFrameStart = 0;
				m_tFrame.iFrameEnd = 2;
				m_tFrame.iMotion = 3;
				m_tFrame.dwSpeed = 100;
				m_tFrame.dwTime = GetTickCount();
			}

			else if (m_pFrameKey == L"PLAYER_DOWN")
			{
				m_tFrame.iFrameStart = 0;
				m_tFrame.iFrameEnd = 2;
				m_tFrame.iMotion = 0;
				m_tFrame.dwSpeed = 100;
				m_tFrame.dwTime = GetTickCount();
			}
			
			break;
		}
		m_ePreState = m_eCurState;
	}
}

D3DXVECTOR3 S4_Player::Get_Dir(bool wKey, bool aKey, bool sKey, bool dKey)
{
	D3DXVECTOR3 vTempDir = { 0.f,0.f,0.f };
	
	if (wKey)
		vTempDir += { 0.0f, -1.0f, 0.0f};
	if (aKey)
		vTempDir += { -1.0f, 0.0f, 0.0f};
	if (sKey)
		vTempDir += { 0.0f, 1.0f, 0.0f};
	if (dKey)
		vTempDir += { 1.0f, 0.0f, 0.0f};

	vTempDir = *D3DXVec3Normalize(&vTempDir, &vTempDir);

	return vTempDir;
}


void S4_Player::KeyInput()
{
	D3DXMATRIX matScale, matRotZ, matTrans;

	

	if (CKeyMgr::Get_Instance()->Key_Pressing(VK_LEFT))
	{

		//m_tInfo.vPos.x -= m_fSpeed;

		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fAngle);
		D3DXMatrixTranslation(&matTrans, -m_fSpeed, 0.f, 0.f);
		
		//m_tInfo.vPos = m_tOriginPos;

		m_tInfo.matWorld = matScale * matRotZ * matTrans;

		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &m_tInfo.matWorld);


		m_tFrame.iMotion = 1;

		LeftKey = true;
		__super::Move_Frame();
	}
	


	else if (CKeyMgr::Get_Instance()->Key_Pressing(VK_RIGHT))
	{
		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fAngle);
		D3DXMatrixTranslation(&matTrans, m_fSpeed, 0.f, 0.f);

		//m_tInfo.vPos = m_tOriginPos;

		m_tInfo.matWorld = matScale * matRotZ * matTrans;

		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &m_tInfo.matWorld);
		m_tFrame.iMotion = 2;
		RightKey = true;
		__super::Move_Frame();
	}


	else if (CKeyMgr::Get_Instance()->Key_Pressing(VK_UP))
	{
		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fAngle);
		D3DXMatrixTranslation(&matTrans, 0.f, -m_fSpeed, 0.f);

		//m_tInfo.vPos = m_tOriginPos;

		m_tInfo.matWorld = matScale * matRotZ * matTrans;

		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &m_tInfo.matWorld);
		m_tFrame.iMotion = 3;

		UpKey = true;
		__super::Move_Frame();
	}


	else if (CKeyMgr::Get_Instance()->Key_Pressing(VK_DOWN))
	{
		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fAngle);
		D3DXMatrixTranslation(&matTrans, 0.f, m_fSpeed, 0.f);

		//m_tInfo.vPos = m_tOriginPos;

		m_tInfo.matWorld = matScale * matRotZ * matTrans;

		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &m_tInfo.matWorld);
		m_tFrame.iMotion = 0;

		DownKey = true;
		__super::Move_Frame();
	}
	else
		m_tFrame.iFrameStart = 1;

	 
	if (CKeyMgr::Get_Instance()->Key_Down(VK_LEFT))
		LeftKey = false;

	if (CKeyMgr::Get_Instance()->Key_Down(VK_RIGHT))
		RightKey = false;

	if (CKeyMgr::Get_Instance()->Key_Down(VK_UP))
		UpKey = false;

	if (CKeyMgr::Get_Instance()->Key_Down(VK_DOWN))
		DownKey = false;

	m_tInfo.vColliderpos.x = m_tInfo.vPos.x;
	m_tInfo.vColliderpos.y = m_tInfo.vPos.y - 25;

}

/*
	��ǻ�� ��Ʈ
	�ð� ��ħ.


*/