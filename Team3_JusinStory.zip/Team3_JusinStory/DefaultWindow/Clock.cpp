#include "stdafx.h"
#include "Clock.h"
#include "KeyMgr.h"


CClock::CClock():
	 m_fHourDistance(0.f)
	,m_fMinuteDistance(0.f)
	,m_ulHourDelay(GetTickCount64())
	,m_ulMinuteDelay(GetTickCount64())
	,m_fHourAngle(0)
	,m_fMinuteAngle(0)
{
	ZeroMemory(reinterpret_cast<void*>(&time), sizeof(time));
}

CClock::~CClock()
{
	Release();
}

void CClock::Initialize()
{
	// �ð� ����
	m_tInfo.vPos = { 100.f , 100.f, 0.f }; 

	// �ð� ũ��
	m_fScaleX = 50.f;
	m_fScaleY = 50.f; 

	// �ð� ������Ʈ( ���� �ð� �߾ӿ� �ִ� ħ�� )
	m_vCenterDot = m_tInfo.vPos;

	// �ޱ�, �� �ʱ�ȭ
	m_fAngle	  =     0.f;
	//m_tInfo.vLook =   { 0.f, -1.f , 0.f };
	
	// ��ħ�� ��ħ�� �Ÿ� �ʱ�ȭ
	  m_fHourDistance = 25.f;
	m_fMinuteDistance = 40.f;

	// ��ħ, ��ħ�� ���� �ð� �߾� ������ �ʱ�ȭ
	  m_vHourHand.vPos   =  m_vCenterDot;                                                                                                          
	  m_vHourHand.vPos.y -= m_fHourDistance;

	  m_vMinuteHand.vPos =  m_vCenterDot;
	  m_vHourHand.vPos.y -= m_fMinuteDistance;

	// ��� ���� ���� �ϱ����� ������ �ʱ�ȭ
	  m_vOriginHour = m_vHourHand;
	m_vOriginMinute = m_vMinuteHand;
	
	// ��,��,�� �׵� �ʱ�ȭ
	D3DXMatrixIdentity(&matScale);
	D3DXMatrixIdentity(&matRotZ);
	D3DXMatrixIdentity(&matTrans);
}

int CClock::Update()
{
	//GetLocalTime(&time);
	//const float fHourAngle = (360.0f / 12) * (time.wHour) + (time.wMinute * 0.5f);
	//const float fMinuteAngle = (360.0f / 10000) * (time.wMinute);

	// ��,��,�� ��ķ� �������.
	 
	// �����̸��� �ޱ۰� ���� �� ���� ��ȯ
	if (m_ulHourDelay + 500 < GetTickCount64())
	{
		m_fHourAngle += D3DXToRadian(1.f);
		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fHourAngle);
		D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

		m_vHourHand.matWorld = matScale * matRotZ * matTrans;

		m_vHourHand.vPos = m_vOriginHour.vPos;
		m_vHourHand.vPos -= {100.f, 75.f, 0.f};

		D3DXVec3TransformCoord(&m_vHourHand.vPos, &m_vHourHand.vPos, &m_vHourHand.matWorld);
		m_ulHourDelay = GetTickCount64();
	}

	if (m_ulMinuteDelay + 100 < GetTickCount64())
	{
		m_fMinuteAngle += D3DXToRadian(1.f);
		D3DXMatrixScaling(&matScale, 1.f, 1.f, 1.f);
		D3DXMatrixRotationZ(&matRotZ, m_fMinuteAngle);
		D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

		m_vMinuteHand.matWorld = matScale * matRotZ * matTrans;

		m_vMinuteHand.vPos = m_vOriginMinute.vPos;
		m_vMinuteHand.vPos -= {100.f, 60.f, 0.f};

		D3DXVec3TransformCoord(&m_vMinuteHand.vPos, &m_vMinuteHand.vPos, &m_vMinuteHand.matWorld);
		m_ulMinuteDelay = GetTickCount64();
	}

	return OBJ_NOEVENT;
}

void CClock::Late_Update()
{
}

void CClock::Render(HDC hDC)
{
	Ellipse(hDC, (int)m_tInfo.vPos.x - m_fScaleX, (int)m_tInfo.vPos.y - m_fScaleY, (int)m_tInfo.vPos.x + m_fScaleX, m_tInfo.vPos.y + m_fScaleY);
	Ellipse(hDC, (int)m_vCenterDot.x - 1, (int)m_vCenterDot.y - 1, (int)m_vCenterDot.x + 1, (int)m_vCenterDot.y + 1);

	MoveToEx(hDC, (int)m_vCenterDot.x, (int)m_vCenterDot.y, nullptr);
	LineTo(hDC, (int)m_vHourHand.vPos.x, (int)m_vHourHand.vPos.y);

	MoveToEx(hDC, (int)m_vCenterDot.x, (int)m_vCenterDot.y, nullptr);
	LineTo(hDC, (int)m_vMinuteHand.vPos.x, (int)m_vMinuteHand.vPos.y);
}

void CClock::Release()
{
}


