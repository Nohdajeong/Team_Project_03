#include "stdafx.h"
#include "Cup.h"

S4_CCup::S4_CCup()
{
}

S4_CCup::~S4_CCup()
{
}

void S4_CCup::Initialize()
{
    m_tInfo.fWidth = 50.f;
    m_tInfo.fHeight = 50.f;
    m_tInfo.vColliderpos = m_tInfo.vPos;
    
}

int S4_CCup::Update()
{
    SetRectPoint(m_tInfo, m_tInfo.fWidth, m_tInfo.fHeight);
    //m_tInfo.vColliderpos = m_tInfo.vPos;
    
    return 0;
}

void S4_CCup::Late_Update()
{
}

void S4_CCup::Render(HDC hDC)
{
    MoveToEx(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y, nullptr);
    LineTo(hDC, m_tInfo.vPoint[1].x, m_tInfo.vPoint[1].y);
    LineTo(hDC, m_tInfo.vPoint[2].x, m_tInfo.vPoint[2].y);
    LineTo(hDC, m_tInfo.vPoint[3].x, m_tInfo.vPoint[3].y);
    LineTo(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y);
}

void S4_CCup::Release()
{
}
