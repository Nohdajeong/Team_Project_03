#include "stdafx.h"
#include "S4_Wall.h"

S4_CWall::S4_CWall()
{
}

S4_CWall::S4_CWall(LINE& tLine)
	:m_tInfo(tLine)
{
}

S4_CWall::S4_CWall(LINEPOINT& _tpoint)
	: m_tInfo(_tpoint)
{
}

S4_CWall::~S4_CWall()
{
}

void S4_CWall::Initialize()
{
	m_tOBB.vCenter.x = (m_tInfo.tpoint.vStartLine.x + m_tInfo.tpoint.vEndLine.x) * 0.5f;
	m_tOBB.vCenter.y = (m_tInfo.tpoint.vStartLine.y + m_tInfo.tpoint.vEndLine.y) * 0.5f;
	m_tOBB.vCenter.z = 0.f;

	m_tOBB.vExtents.x = (m_tInfo.tpoint.vStartLine.x + m_tInfo.tpoint.vEndLine.x) * 0.5f;
	m_tOBB.vExtents.y = (m_tInfo.tpoint.vStartLine.x + m_tInfo.tpoint.vEndLine.x) * 0.5f;
	m_tOBB.vCenter.z = 0.f;

	m_tOBB.vAxis[0] = D3DXVECTOR3{ 1.0f, 0.0f, 0.0f };
	m_tOBB.vAxis[1] = D3DXVECTOR3{ 0.0f, 1.0f, 0.0f };
	m_tOBB.vAxis[2] = D3DXVECTOR3{ 0.0f, 0.0f, 1.0f };
}

int S4_CWall::Update()
{
	return OBJ_NOEVENT;
}

void S4_CWall::Late_Update()
{
}

void S4_CWall::Render(HDC hDC)
{
	Rectangle(hDC, int(m_tInfo.tpoint.vStartLine.x), int(m_tInfo.tpoint.vStartLine.y), int(m_tInfo.tpoint.vEndLine.x), int(m_tInfo.tpoint.vEndLine.y));
}

void S4_CWall::Release()
{
}
