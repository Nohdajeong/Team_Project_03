#pragma once
#include "Obj_S1.h"
class CTrash_S1 :
    public CObj_S1
{
public:
	CTrash_S1();
	virtual ~CTrash_S1();

public:
	// CObj��(��) ���� ��ӵ�
	virtual void Initialize() override;
	virtual int Update() override;
	virtual void Late_Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

	D3DXVECTOR3 Get_TrashCOLCENTER(void) { 
		D3DXVECTOR3 COL_CENTER;
		COL_CENTER = { (m_vCOLTrash[POINT_L_T].x + m_vCOLTrash[POINT_R_T].x) * 0.5f,
		(m_vCOLTrash[POINT_R_B].y + m_vCOLTrash[POINT_L_B].y) * 0.5f, 0.5f };
		return COL_CENTER; }
	D3DXVECTOR3 Get_TrashCOLPoint(Point_V number) { return m_vCOLTrash[number]; }

private:
	//D3DXVECTOR3 m_vTrash[POINT_END];
	//D3DXVECTOR3	m_vOriginTrash[POINT_END];

	//�÷��̾� �ݶ��̴��� ����
	D3DXVECTOR3 m_vCOLTrash[POINT_END];
	D3DXVECTOR3	m_vOriginCOLAPoint[POINT_END];

	D3DXMATRIX matCOLPoint_World;
};

