#include "stdafx.h"
#include "S4_Obj.h"

S4_Obj::S4_Obj() : m_fSpeed(0.f),m_fAngle(0.f),m_fScaleX(0.f),m_fScaleY(0.f), m_eDir(DIR_END), m_eRender(RENDER_END)
{
	ZeroMemory(&m_tInfo, sizeof(INFO));
	ZeroMemory(&m_tOBB, sizeof(OBB));
}

S4_Obj::~S4_Obj()
{
}

void S4_Obj::SetRectPoint(INFO& _Info, float _fCX, float _fCY)
{
	_Info.vPoint[0] = _Info.vColliderpos + D3DXVECTOR3(-_fCX * 0.5f,  _fCY * 0.5f , 0.f);
	_Info.vPoint[1] = _Info.vColliderpos + D3DXVECTOR3(-_fCX * 0.5f, -_fCY * 0.5f, 0.f);
	_Info.vPoint[2] = _Info.vColliderpos + D3DXVECTOR3( _fCX * 0.5f, -_fCY * 0.5f, 0.f);
	_Info.vPoint[3] = _Info.vColliderpos + D3DXVECTOR3( _fCX * 0.5f,  _fCY * 0.5f, 0.f);
}

void S4_Obj::Move_Frame()
{
	if (m_tFrame.dwTime + m_tFrame.dwSpeed < GetTickCount())
	{
		++m_tFrame.iFrameStart;

		if (m_tFrame.iFrameStart > m_tFrame.iFrameEnd)
			m_tFrame.iFrameStart = 0;

		m_tFrame.dwTime = GetTickCount();

	}
}
