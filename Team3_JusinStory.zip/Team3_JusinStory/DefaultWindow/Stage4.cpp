#include "stdafx.h"
#include "Stage4.h"
#include "BmpMgr.h"
#include "S4_ObjMgr.h"
#include "S4_LineMgr.h"
#include "S4_WallMgr.h"
#include "KeyMgr.h"
#include "SceneMgr.h"
#include <ctime>

//#include "SoundMgr.h"

#include "S4_Player.h"

CStage4::CStage4():m_pPlayer(nullptr),m_pComputer(nullptr),m_pClock(nullptr),m_bEdit(false), m_bStart(true)
{
	srand(unsigned(time(NULL)));
}

CStage4::~CStage4()
{
}

void CStage4::Initialize()
{
	iRandom1 = rand() % 4;
	iRandom2 = rand() % 4;

	CBmpMgr::Get_Instance()->Insert_Bmp(L"../Image/Lobby.bmp", L"Lobby");
	S4_CWallMgr::Get_Instance()->Initialize();

	if (!m_pPlayer)
	{
		m_pPlayer = new S4_Player;
		m_pPlayer->Initialize();
	}


	for (int i = 0; i < 4; ++i)
	{
		m_pCup[i] = new S4_CCup;
		D3DXVECTOR3 vTempPos = { 0.f,0.f,0.f };

		if (i == 0)
		{
			vTempPos = { float(150.f), 300.f, 0.f };
		}
		else
		{
			vTempPos = { m_pCup[0]->Get_Info().vPos.x + 150 * i, 300.f, 0.f };
		}

		m_pCup[i]->SetPos(vTempPos);
		m_pCup[i]->Initialize();
		
	}

	int iRandom = rand() % 4;

	if (!m_pAnswerCube)
	{
		m_pAnswerCube = new S4_CAnswerCube;
		m_pAnswerCube->Set_Target(m_pCup[iRandom]);
		m_pAnswerCube->Initialize();
	}


	//m_pCup[iRandom]->Set_Target()
	
	
	//S4_CWallMgr::Get_Instance()->Initialize();

	/*if (!m_pComputer)
	{
		m_pComputer = new CComputer;
		m_pComputer->Initialize();
	}

	if (!m_pClock)
	{
		m_pClock = new CClock;
		m_pClock->Initialize();
	}*/

#ifdef _DEBUG
	if (::AllocConsole() == TRUE)
	{
		FILE* nfp[3];
		freopen_s(nfp + 0, "CONOUT$", "rb", stdin);
		freopen_s(nfp + 1, "CONOUT$", "wb", stdout);
		freopen_s(nfp + 2, "CONOUT$", "wb", stderr);
		std::ios::sync_with_stdio();
	}
#endif // _DEBUG
}

void CStage4::Update()
{
	m_pPlayer->Update();

	for (int i = 0; i < 4; ++i)
	{
		m_pCup[i]->Update();
	}

	m_pAnswerCube->Update();

	
	Trickery();

		

	if (CKeyMgr::Get_Instance()->Key_Down('Q'))
	{
		m_bEdit = true;
	}
	if (CKeyMgr::Get_Instance()->Key_Down('W'))
	{
		m_bEdit = false;
	}

	float fX = m_pPlayer->Get_Info().vPos.x;
	float fY = m_pPlayer->Get_Info().vPos.y;

	if(m_bEdit)
		S4_CLineMgr::Get_Instance()->Update();
	bool test = false;

	test = S4_CLineMgr::Get_Instance()->Check_Collision(*m_pPlayer);
	//S4_CWallMgr::Get_Instance()->Update();
	
	//test = S4_CLineMgr::Get_Instance()->Collision_VectorLine(m_pPlayer, &fX, &fY);

	if(test)
		cout << test << endl;


	if (CKeyMgr::Get_Instance()->Key_Pressing('P')) {
		CSceneMgr::Get_Instance()->Scene_Change(SC_ENDING);
	}
}

void CStage4::Late_Update()
{ 
	//CObjMgr::Get_Instance()->Late_Update();
}

void CStage4::Render(HDC hDC)
{
	
	HDC hLobbyDC = CBmpMgr::Get_Instance()->Find_Img(L"Lobby");
	
	GdiTransparentBlt(hDC, 0, 0, 800, 600, hLobbyDC, 0, 0, 800, 600,RGB(0,0,1));

	m_pPlayer->Render(hDC);

	for (int i = 0; i < 4; ++i)
	{
		m_pCup[i]->Render(hDC);
	}

	m_pAnswerCube->Render(hDC);
	S4_CLineMgr::Get_Instance()->Render(hDC);
}

void CStage4::Release()
{
	Safe_Delete<S4_Obj*>(m_pPlayer);
	Safe_Delete<S4_Obj*>(m_pComputer);
	Safe_Delete<S4_Obj*>(m_pClock);

	for (int i = 0; i < 4; ++i)
	{
		Safe_Delete<S4_Obj*>(m_pCup[i]);
	}

	Safe_Delete<S4_Obj*>(m_pAnswerCube);

#ifdef _DEBUG

	FreeConsole();

#endif
}

void CStage4::Trickery()
{
	bool bXtrans = false;

	if (iRandom2 == iRandom1)
	{
		while (true)
		{
			iRandom2 = rand() % 4;
			if (iRandom1 != iRandom2)
				break;
		}
	}
	
	D3DXVECTOR3 Random1Dir = m_pCup[iRandom2]->Get_Info().vColliderpos - m_pCup[iRandom1]->Get_Info().vColliderpos;
	D3DXVECTOR3 Random2Dir = m_pCup[iRandom1]->Get_Info().vColliderpos - m_pCup[iRandom2]->Get_Info().vColliderpos;

	if (m_ulDelay + 100 < GetTickCount64() && m_iIncrease < 100)
	{
		m_pCup[iRandom1]->Get_Info().vColliderpos.y -= 5;
		m_pCup[iRandom2]->Get_Info().vColliderpos.y += 5;
		m_iIncrease += 5;

		m_ulDelay = GetTickCount64();
		
		bXtrans = true;
	} 

	if (bXtrans)
	{
		
	}
	
	
}
