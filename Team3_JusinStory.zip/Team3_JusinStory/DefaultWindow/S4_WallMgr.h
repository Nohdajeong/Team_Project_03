#pragma once
#include "S4_Wall.h"
#include "S4_Obj.h"

class S4_CWallMgr
{
public:
	 S4_CWallMgr();
	~S4_CWallMgr();

public:
	void		Load_Wall();
	void		Save_Wall();
	bool		Collision_OBBWall();

public:
	void		Initialize();
	int			Update();
	void		Late_Update();
	void		Render(HDC hDC);
	void		Release();


public:
	static S4_CWallMgr* Get_Instance()
	{
		if (!m_pInstance)
		{
			m_pInstance = new S4_CWallMgr;
		}

		return m_pInstance;
	}
	static void		Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}

private:
	list<S4_CWall*>			m_WallList;
	LINEPOINT				m_tLintPoint;

	static S4_CWallMgr*		m_pInstance;
};

