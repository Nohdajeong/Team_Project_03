#include "stdafx.h"
#include "AnswerCube.h"


S4_CAnswerCube::S4_CAnswerCube()
{
}

S4_CAnswerCube::~S4_CAnswerCube()
{
}

void S4_CAnswerCube::Initialize()
{
	m_tInfo.fHeight = 25.f;
	m_tInfo.fWidth = 25.f;
	
	m_tInfo.vColliderpos = m_tInfo.vPos;

	SetRectPoint(m_tInfo, m_tInfo.fWidth, m_tInfo.fHeight);
}

int S4_CAnswerCube::Update()
{
	m_tInfo.vPos = m_pTarget->Get_Info().vPos;
	m_tInfo.vColliderpos = m_pTarget->Get_Info().vColliderpos;
	SetRectPoint(m_tInfo, m_tInfo.fWidth, m_tInfo.fHeight);
	return 0;
}

void S4_CAnswerCube::Late_Update()
{

}

void S4_CAnswerCube::Render(HDC hDC)
{
	MoveToEx(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y, nullptr);
	LineTo(hDC, m_tInfo.vPoint[1].x, m_tInfo.vPoint[1].y);
	LineTo(hDC, m_tInfo.vPoint[2].x, m_tInfo.vPoint[2].y);
	LineTo(hDC, m_tInfo.vPoint[3].x, m_tInfo.vPoint[3].y);
	LineTo(hDC, m_tInfo.vPoint[0].x, m_tInfo.vPoint[0].y);
}

void S4_CAnswerCube::Release()
{
}
