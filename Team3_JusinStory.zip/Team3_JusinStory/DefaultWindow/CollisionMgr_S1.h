#pragma once

#include "Obj_S1.h"

class CCollisionMgr_S1
{
public:
    CCollisionMgr_S1();
    ~CCollisionMgr_S1();

public:
    static bool   Collision_OBB(
        D3DXVECTOR3& _DstCenter,
        const D3DXVECTOR3 _Dst_LT, const D3DXVECTOR3 _Dst_RT,
        const D3DXVECTOR3 _Dst_RB, const D3DXVECTOR3 _Dst_LB,

        D3DXVECTOR3& _SrcCenter,
        const D3DXVECTOR3 _Src_LT, const D3DXVECTOR3 _Src_RT,
        const D3DXVECTOR3 _Src_RB, const D3DXVECTOR3 _Src_LB
    );
    static void Collision_Overlap(
        D3DXVECTOR3& _DstCenter,
        const D3DXVECTOR3 _Dst_LT, const D3DXVECTOR3 _Dst_RT,
        const D3DXVECTOR3 _Dst_RB, const D3DXVECTOR3 _Dst_LB,

        D3DXVECTOR3& _SrcCenter,
        const D3DXVECTOR3 _Src_LT, const D3DXVECTOR3 _Src_RT,
        const D3DXVECTOR3 _Src_RB, const D3DXVECTOR3 _Src_LB
    );


    static bool PolygonCollision(const vector<D3DXVECTOR3>& polygon1, const vector<D3DXVECTOR3>& polygon2, D3DXVECTOR3& collisionNormal,
        float& _minOverlap, float& _collisionEdgeIndex1, float& _collisionEdgeIndex2);

    static bool AxisOverlap(
        const vector<D3DXVECTOR3>& polygon1, const vector<D3DXVECTOR3>& polygon2,
        const D3DXVECTOR3& axis, float& minOverlap);

    static void ResolveCollision(vector<D3DXVECTOR3>& polygon1, vector<D3DXVECTOR3>& polygon2, D3DXVECTOR3& collisionNormal,
        float _minOverlap, float _collisionEdgeIndex1, float _collisionEdgeIndex2);

    static D3DXVECTOR3 GetCollisionNormal(const D3DXVECTOR3& obb1Center, const D3DXVECTOR3& obb2Center);


    static void   Collision_Rect(list<CObj_S1*> _Dst, list<CObj_S1*> _Src);
    static void   Collision_RectEx(list<CObj_S1*> _Dst, list<CObj_S1*> _Src);
    static bool   Check_Rect(CObj_S1* _Dst, CObj_S1* _Src, float* _pX, float* _pY);


    static void   Collision_Sphere(list<CObj_S1*> _Dst, list<CObj_S1*> _Src);
    static bool   Check_Sphere(CObj_S1* _Dst, CObj_S1* _Src);

public:
    static D3DXVECTOR3 m_VectorMain;
    static float distance;
};
