#include "stdafx.h"
#include "Stage3.h"
#include "BmpMgr_S3.h"
#include "ObjMgr_S3.h"
#include "AbstractFactory_S3.h"
#include "Player_S3.h"
#include "Monster_S3.h"
#include "KeyMgrS2.h"
#include "SceneMgr.h"

CStage3::CStage3()
{
}

CStage3::~CStage3()
{
	Release();
}

void CStage3::Initialize()
{
	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/Class.bmp", L"Class");
	
	CObjMgr_S3::Get_Instance()->Add_Object(PLAYER, CAbstractFactory_S3<CPlayer_S3>::Create());
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(110.f, 200.f));
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(275.f, 200.f));
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(440.f, 200.f));
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(110.f, 360.f));
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(275.f, 360.f));
	CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, CAbstractFactory_S3<CMonster_S3>::Create(440.f, 360.f));
}

void CStage3::Update()
{
	CObjMgr_S3::Get_Instance()->Update();
}

void CStage3::Late_Update()
{
	CObjMgr_S3::Get_Instance()->Late_Update();

	bool MTarget = CObjMgr_S3::Get_Instance()->Get_Dead(MONSTER);
	if (MTarget) {
		CSceneMgr::Get_Instance()->Scene_Change(SC_STAGE2);
	}
}

void CStage3::Render(HDC hDC)
{
	HDC		hClassDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"Class");
	BitBlt(hDC, 0, 0, 800, 600, hClassDC, 0, 0, SRCCOPY);
	
	CObjMgr_S3::Get_Instance()->Render(hDC);
}

void CStage3::Release()
{
	CObjMgr_S3::Get_Instance()->Delete_ID(PLAYER);
	CObjMgr_S3::Get_Instance()->Delete_ID(MONSTER);
	CBmpMgr_S3::Get_Instance()->Destroy_Instance();
}
