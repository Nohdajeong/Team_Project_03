#pragma once
#include "S4_Obj.h"
class CComputer :
    public S4_Obj
{
public:
             CComputer();
    virtual ~CComputer();

public:
    virtual void  Initialize()       override;
    virtual int   Update()           override;
    virtual void  Late_Update()      override;
    virtual void  Render(HDC hDC)    override;
    virtual void  Release()          override;

private:
    float   m_fScaleX;
    float   m_fScaleY;
    
};

