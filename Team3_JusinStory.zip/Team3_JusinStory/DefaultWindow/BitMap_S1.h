#pragma once

#include "Define.h"

class CBitMap_S1
{
public:
	CBitMap_S1();
	~CBitMap_S1();

public:
	HDC			Get_MemDC() { return m_hMemDC; }

	void		Load_Bmp(const TCHAR* pFilePath);
	void		Release();

private:
	HDC			m_hMemDC;
	HBITMAP		m_hBitMap;
	HBITMAP		m_hOldBmp;

};
