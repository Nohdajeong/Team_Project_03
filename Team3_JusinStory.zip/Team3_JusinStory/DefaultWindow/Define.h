#pragma once
#include "stdafx.h"

#define		WINCX		800
#define		WINCY		600
#define		VK_MAX		0xff
#define		PURE		= 0
#define		PI			3.141592f
#define		OBJ_DEAD	 1
#define		OBJ_NOEVENT	 0

#define		One_Block    100.f
#define		Start_X		 800.f
#define		Start_Y		 2140.f


extern	HWND	g_hWnd;

typedef struct tagInfo
{
	D3DXVECTOR3		vPos;
	D3DXVECTOR3		vPrepos;
	
	D3DXVECTOR3		vDir;
	D3DXVECTOR3		vLook;

	D3DXVECTOR3		vPoint[4]; // �簢���� ǥ���ϱ����� �� ���� ��
	D3DXVECTOR3		vOriginPoint[4];
	D3DXMATRIX		matWorld;
	
	float			fWidth;
	float			fHeight;

	D3DXVECTOR3		vColliderpos;
	D3DXVECTOR3		vColliderOriginPos;
}INFO;

struct OBB
{
	D3DXVECTOR3		vCenter; // OBB�� �߽���
	D3DXVECTOR3		vExtents; // OBB�� �� �� ���������� ���� ũ�� (������ ��)
	D3DXVECTOR3		vAxis[3]; // OBB�� ���� �� ���� (����ȭ�� ���¿��� ��)
};

static D3DXVECTOR3		Get_Mouse()
{
	POINT		Pt{};

	GetCursorPos(&Pt);
	ScreenToClient(g_hWnd, &Pt);

	return D3DXVECTOR3((float)Pt.x, (float)Pt.y, 0.f);
}

enum DIRECTION { LEFT = -1, RIGHT = 1, UP, DOWN, DIR_END };
enum OBJID { CAR, PLAYBOX, PLAYER, BUTTON, BIRD, BLOCK, TRASH, BLOCKJ, BLOCKU, BLOCKS, BLOCKI, BLOCKN, MONSTER, WAKE_MONSTER, OBJID_END };
enum SCENEID { SC_LOGO, SC_STAGE1, SC_STAGE2, SC_STAGE3, SC_STAGE4, SC_ENDING, SC_END };
enum RENDERID { BACKGROUND, GAMEOBJECT, EFFECT, UI, RENDER_END };
enum CHANNELID { SOUND_EFFECT, SOUND_BGM, MAXCHANNEL };

//�߰�
enum Point_V { POINT_L_T, POINT_R_T, POINT_R_B, POINT_L_B, POINT_END };
enum class CAR_TYPE { CAR_1, CAR_2, CAR_3, CAR_4, CAR_5, CAR_6, BUS_1, BUS_2, CAR_END };


class CTag_Finder
{
public:
	CTag_Finder(const TCHAR* pString) : m_pString(pString) {}
public:
	template<typename T>
	bool operator()(T& Pair)
	{
		return !lstrcmp(m_pString, Pair.first);
	}

private:
	const TCHAR* m_pString;
};

class CDeleteObj
{
public:
	template<typename T>
	void operator()(T& Temp)
	{
		if (Temp)
		{
			delete Temp;
			Temp = nullptr;
		}
	}

};

class CDeleteMap
{
public:
	template<typename T>
	void operator()(T& Pair)
	{
		if (Pair.second)
		{
			delete Pair.second;
			Pair.second = nullptr;
		}
	}
};

template<typename T>
void		Safe_Delete(T& Temp)
{
	if(Temp)
	{
		delete Temp;
		Temp = nullptr;
	}
}

struct DeleteObj
{
	template<typename T>
	void operator()(T& Temp)
	{
		if(Temp)
		{
			delete Temp;
			Temp = nullptr;
		}
	}
};

typedef struct tagFrame
{
	int			iFrameStart;
	int			iFrameEnd;
	int			iMotion;

	DWORD		dwSpeed;
	DWORD		dwTime;

}FRAME;

typedef	struct tagLinePoint
{
	tagLinePoint() { ZeroMemory(this, sizeof(tagLinePoint)); }
	//tagLinePoint(float _fX, float _fY) : fX(_fX), fY(_fY) {}

	D3DXVECTOR3 vStartLine;
	D3DXVECTOR3 vEndLine;

}LINEPOINT;


typedef struct tagLine
{
	tagLine() { ZeroMemory(this, sizeof(tagLine)); }
	tagLine(LINEPOINT& _tpoint)
		: tpoint(_tpoint) { }

	LINEPOINT	tpoint;

}LINE;