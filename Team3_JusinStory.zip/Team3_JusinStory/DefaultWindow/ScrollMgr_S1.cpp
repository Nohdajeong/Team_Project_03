#include "stdafx.h"
#include "ScrollMgr_S1.h"

CScrollMgr_S1* CScrollMgr_S1::m_pInstance = nullptr;

CScrollMgr_S1::CScrollMgr_S1()
	: m_fScrollX(0.f), m_fScrollY(0.f)
{
}


CScrollMgr_S1::~CScrollMgr_S1()
{
}

void CScrollMgr_S1::Scroll_Lock() 
{
	if (0.f < m_fScrollX)
		m_fScrollX = 0.f;

	if (0.f < m_fScrollY)
		m_fScrollY = 0.f;

	if (WINCX - 1975 > m_fScrollX)
		m_fScrollX = WINCX - 1975;

	if (WINCY - 2500 > m_fScrollY)
		m_fScrollY = WINCY - 2500;

}
