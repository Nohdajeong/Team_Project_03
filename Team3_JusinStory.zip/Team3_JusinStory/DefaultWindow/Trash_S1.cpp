#include "stdafx.h"
#include "Trash_S1.h"
#include "Player_S1.h"
#include "ScrollMgr_S1.h"

CTrash_S1::CTrash_S1()
{
	D3DXMatrixIdentity(&matCOLPoint_World);
}

CTrash_S1::~CTrash_S1()
{
	Release();
}

void CTrash_S1::Initialize()
{

	//m_vCOLTrash[POINT_L_T] = { 1130.f, 1880.f, 0.f };
	//m_vCOLTrash[POINT_R_T] = { 1230.f, 1880.f, 0.f };
	//m_vCOLTrash[POINT_R_B] = { 1230.f, 1980.f, 0.f };
	//m_vCOLTrash[POINT_L_B] = { 1130.f, 1980.f, 0.f };

	m_vCOLTrash[POINT_L_T] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vCOLTrash[POINT_R_T] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vCOLTrash[POINT_R_B] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y + 50.f, 0.f };
	m_vCOLTrash[POINT_L_B] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y + 50.f, 0.f };

	for (int i = POINT_L_T; i < POINT_END; ++i)
	{	m_vOriginCOLAPoint[i] = m_vCOLTrash[i];	}

	for (int i = 0; i < 4; ++i) {
		Push_vPoint(m_vCOLTrash[i]);
		Push_m_VOriginPoint(m_vOriginCOLAPoint[i]);
	}
}

int CTrash_S1::Update()
{
	//�ݶ��̴� ������ : �̵�, ȸ��, ����
	D3DXMATRIX matScale_C, matRotZ_C, matTrans_C;

	D3DXMatrixScaling(&matScale_C, 1.f, 1.f, 1.f);
	D3DXMatrixRotationZ(&matRotZ_C, 0.f);
	D3DXMatrixTranslation(&matTrans_C, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

	matCOLPoint_World = matScale_C * matRotZ_C * matTrans_C;

	m_vCOLTrash[POINT_L_T] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vCOLTrash[POINT_R_T] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vCOLTrash[POINT_R_B] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y + 50.f, 0.f };
	m_vCOLTrash[POINT_L_B] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y + 50.f, 0.f };

	for (int i = POINT_L_T; i < POINT_END; ++i)
	{
		m_vCOLTrash[i] = m_vOriginCOLAPoint[i];
	//	m_vCOLTrash[i] -= { Start_X, Start_Y, 0.f };

		D3DXVec3TransformCoord(&m_vCOLTrash[i], &m_vCOLTrash[i], &matCOLPoint_World);
	}

	for (int i = 0; i < 4; ++i) {
		m_vecPoint[i] = m_vCOLTrash[i];
		m_vecOriginPoint[i] = m_vOriginCOLAPoint[i];
	}

	return 0;
}

void CTrash_S1::Late_Update()
{
}

void CTrash_S1::Render(HDC hDC)
{
	int		iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int		iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	if (CPlayer_S1::Collider_Mode == true) {
		ColliderRender(hDC, m_vCOLTrash[POINT_L_T], m_vCOLTrash[POINT_R_T],
							m_vCOLTrash[POINT_R_B], m_vCOLTrash[POINT_L_B]);
	}

//	Rectangle(hDC, m_vCOLTrash[POINT_L_T].x + iScrollX, m_vCOLTrash[POINT_R_T].y + iScrollY,
//		m_vCOLTrash[POINT_R_B].x + iScrollX, m_vCOLTrash[POINT_L_B].y + iScrollY);

}

void CTrash_S1::Release()
{

}
