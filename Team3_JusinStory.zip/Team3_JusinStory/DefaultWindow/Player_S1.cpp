#include "stdafx.h"
#include "Player_S1.h"
#include "KeyMgr_S1.h"
#include "BmpMgr_S1.h"
#include "ScrollMgr_S1.h"

bool CPlayer_S1::Collider_Mode = false;

CPlayer_S1::CPlayer_S1() : m_fAngle(0.f), m_magni(1.f)
{
	D3DXMatrixIdentity(&matPlayer);
	D3DXMatrixIdentity(&matAPoint);
	D3DXMatrixIdentity(&matAPoint_World);
	D3DXMatrixIdentity(&matCOLPoint_World);
}

CPlayer_S1::~CPlayer_S1()
{
	Release();
}

void CPlayer_S1::Initialize()
{
	m_tInfo.vPos = { Start_X, Start_Y, 0.f };
	
	m_vPlayer[1] = { m_tInfo.vPos.x + 50.f,  m_tInfo.vPos.y - 50.f, 0.f };
	m_vPlayer[2] = { m_tInfo.vPos.x + 50.f,  m_tInfo.vPos.y + 50.f, 0.f };
	m_vPlayer[3] = { m_tInfo.vPos.x - 50.f,  m_tInfo.vPos.y + 50.f, 0.f };
	m_vPlayer[0] = { m_tInfo.vPos.x - 50.f,  m_tInfo.vPos.y - 50.f, 0.f };

	for (int i = POINT_L_T; i < POINT_END; ++i)
	{	m_vOriginPoint[i] = m_vPlayer[i];	}

	m_vACenterPoint = { Start_X, Start_Y - 80.f, 0.f };

	m_vAPoint[1] = { m_vACenterPoint.x + 30.f,  m_vACenterPoint.y - 15.f, 0.f };
	m_vAPoint[2] = { m_vACenterPoint.x + 30.f,  m_vACenterPoint.y + 15.f, 0.f };
	m_vAPoint[3] = { m_vACenterPoint.x - 30.f,  m_vACenterPoint.y + 15.f, 0.f };
	m_vAPoint[0] = { m_vACenterPoint.x - 30.f,  m_vACenterPoint.y - 15.f, 0.f };
	
	for (int i = POINT_L_T; i < POINT_END; ++i)
	{	m_vOriginAPoint[i] = m_vAPoint[i];	}
	m_vOriginACenterPoint = m_vACenterPoint;

	m_tInfo.vLook = { 0.f, 1.f, 0.f };
	m_fSpeed = 5.f;

	D3DXVECTOR3 Temp_vCenter = (((m_vPlayer[POINT_L_B] + m_vPlayer[POINT_R_B]) * 0.5f) + m_tInfo.vPos) * 0.5f;

	m_vCOLPoint[1] = { Temp_vCenter.x + 32.f,  Temp_vCenter.y - 15.f, 0.f };
	m_vCOLPoint[2] = { Temp_vCenter.x + 32.f,  Temp_vCenter.y + 20.f, 0.f };
	m_vCOLPoint[3] = { Temp_vCenter.x - 32.f,  Temp_vCenter.y + 20.f, 0.f };
	m_vCOLPoint[0] = { Temp_vCenter.x - 32.f,  Temp_vCenter.y - 15.f, 0.f };

	for (int i = POINT_L_T; i < POINT_END; ++i)
	{	m_vOriginCOLAPoint[i] = m_vCOLPoint[i];	}

	CBmpMgr_S1::Get_Instance()->Insert_Bmp(L"../Data/Char_100.bmp", L"Char");

	m_tFrame.iFrameStart = 0;
	m_tFrame.iFrameEnd = 1;
	m_tFrame.iMotion = 1;
	m_tFrame.dwSpeed = 300;
	m_tFrame.dwTime = (DWORD)GetTickCount64();

	for (int i = 0; i < 4; ++i) {
		Push_vPoint(m_vCOLPoint[i]);
		Push_m_VOriginPoint(m_vOriginCOLAPoint[i]);
	}
}

int CPlayer_S1::Update()
{
	Key_Input();
	OffSet();

	//�÷��̾� ������ : �̵��� ũ�⸸ ����, ���� ȸ���� X
	D3DXMATRIX	matScale, matRotZ, matTrans;

	D3DXMatrixScaling(&matScale, 1.f * m_magni, 1.f * m_magni, 1.f * m_magni);
	D3DXMatrixRotationZ(&matRotZ, 0.f);
	D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

	m_tInfo.matWorld = matScale * matRotZ * matTrans;

	for (int i = POINT_L_T; i < POINT_END; ++i)
	{
		m_vPlayer[i] = m_vOriginPoint[i];
		m_vPlayer[i] -= { Start_X, Start_Y, 0.f };

		D3DXVec3TransformCoord(&m_vPlayer[i], &m_vPlayer[i], &m_tInfo.matWorld);
	}


	//����(�ַο�����Ʈ) ������ : �̵�, ȸ��, ����
	D3DXMATRIX matScale_A, matRotZ_A1, matTrans_A;

	D3DXMatrixScaling(&matScale_A, 1.f * m_magni, 1.f * m_magni, 1.f * m_magni);
	D3DXMatrixRotationZ(&matRotZ_A1, m_fAngle);
	D3DXMatrixTranslation(&matTrans_A, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

	matAPoint_World = matScale_A * matRotZ_A1 * matTrans_A;

	m_vACenterPoint = m_vOriginACenterPoint;
	m_vACenterPoint -= { Start_X, Start_Y, 0.f };

	m_vAPoint[1] = { m_vACenterPoint.x + 30.f,  m_vACenterPoint.y - 15.f, 0.f };
	m_vAPoint[2] = { m_vACenterPoint.x + 30.f,  m_vACenterPoint.y + 15.f, 0.f };
	m_vAPoint[3] = { m_vACenterPoint.x - 30.f,  m_vACenterPoint.y + 15.f, 0.f };
	m_vAPoint[0] = { m_vACenterPoint.x - 30.f,  m_vACenterPoint.y - 15.f, 0.f };
	
	for (int i = POINT_L_T; i < POINT_END; ++i)
	{
		D3DXVec3TransformCoord(&m_vAPoint[i], &m_vAPoint[i], &matAPoint_World);
	}

	//�ݶ��̴� ������ : �̵�, ȸ��, ����
	//D3DXMATRIX matScale_C, matRotZ_C, matTrans_C;
	//D3DXMatrixScaling(&matScale_C, 1.f * m_magni, 1.f * m_magni, 1.f * m_magni);
	//D3DXMatrixRotationZ(&matRotZ_C, 0.f);
	//D3DXMatrixTranslation(&matTrans_C, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);
	//matAPoint_World = matScale_C * matRotZ_C * matTrans_C;

	D3DXVECTOR3 Temp_vCenter = (((m_vPlayer[POINT_L_B] + m_vPlayer[POINT_R_B]) * 0.5f) + m_tInfo.vPos) * 0.5f;

	m_vCOLPoint[1] = { Temp_vCenter.x + 32.f,  Temp_vCenter.y - 15.f, 0.f };
	m_vCOLPoint[2] = { Temp_vCenter.x + 32.f,  Temp_vCenter.y + 20.f, 0.f };
	m_vCOLPoint[3] = { Temp_vCenter.x - 32.f,  Temp_vCenter.y + 20.f, 0.f };
	m_vCOLPoint[0] = { Temp_vCenter.x - 32.f,  Temp_vCenter.y - 15.f, 0.f };

	//for (int i = POINT_L_T; i < POINT_END; ++i)
	//{
	////	m_vCOLPoint[i] = m_vOriginCOLAPoint[i];
	////	m_vCOLPoint[i] -= { Start_X, Start_Y, 0.f };

	//	D3DXVec3TransformCoord(&m_vCOLPoint[i], &m_vCOLPoint[i], &matCOLPoint_World);
	//}

	for (int i = 0; i < 4; ++i) {
		m_vecPoint[i] = m_vCOLPoint[i];
		m_vecOriginPoint[i] = m_vOriginCOLAPoint[i];
	}
	return 0;
}

void CPlayer_S1::Late_Update()
{
	if (CKeyMgr_S1::Get_Instance()->Key_Down(VK_TAB))
	{	CPlayer_S1::Collider_Mode = !CPlayer_S1::Collider_Mode;	}

	if (m_tInfo.vPos.x < 300.f) { m_tInfo.vPos.x = 300.f; }
	if (m_tInfo.vPos.x > 1675.f) { m_tInfo.vPos.x = 1675.f; }
		
	if (m_tInfo.vPos.y < 200.f) { m_tInfo.vPos.y = 200.f; }
	if (m_tInfo.vPos.y > 2200.f) { m_tInfo.vPos.y = 2200.f; }

}

void CPlayer_S1::Key_Input() {
	D3DXVECTOR3 vCenterPos = (((m_vAPoint[POINT_L_T] + m_vAPoint[POINT_R_T]) * 0.5f)
							+ ((m_vAPoint[POINT_L_B] + m_vAPoint[POINT_R_B]) * 0.5f)) * 0.5f;

	if (CKeyMgr_S1::Get_Instance()->Key_Down(VK_LEFT))
	{	m_fAngle -= D3DXToRadian(45);	}
	if (CKeyMgr_S1::Get_Instance()->Key_Down(VK_RIGHT))
	{	m_fAngle += D3DXToRadian(45);	}

	if (CKeyMgr_S1::Get_Instance()->Key_Down(VK_SPACE))
	{
		if (m_tInfo.vPos.y >= vCenterPos.y + 10.f)
		{	m_tFrame.iMotion = 1;	}
		else {	m_tFrame.iMotion = 0;	}

		//��ü �̵��ϱ� ��, �̵� ���� ����ֱ�
		m_tInfo.vDir = vCenterPos - m_tInfo.vPos; //�������� ȭ��ǥ�� �ٶ󺸴� ���� ���
		D3DXVec3Normalize(&m_tInfo.vDir, &m_tInfo.vDir);
				
		D3DXMatrixTranslation(&matPlayer, m_tInfo.vDir.x * One_Block, m_tInfo.vDir.y * One_Block, 0.f);
		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &matPlayer);	
	}

}

void CPlayer_S1::OffSet()
{
	int	iOffSetMinX = 300; 		int	iOffSetMaxX = 500;
	int	iOffSetMinY = 200;		int	iOffSetMaxY = 400;

	int	iScrollX = int(CScrollMgr_S1::Get_Instance()->Get_ScrollX());
	int	iScrollY = int(CScrollMgr_S1::Get_Instance()->Get_ScrollY());
	float fX = CScrollMgr_S1::Get_Instance()->Get_ScrollX();

	if (iOffSetMinX > m_tInfo.vPos.x + iScrollX)
		CScrollMgr_S1::Get_Instance()->Set_ScrollX(m_fSpeed);

	if (iOffSetMaxX < m_tInfo.vPos.x + iScrollX)
		CScrollMgr_S1::Get_Instance()->Set_ScrollX(-m_fSpeed);

	if (iOffSetMinY > m_tInfo.vPos.y + iScrollY)
		CScrollMgr_S1::Get_Instance()->Set_ScrollY(m_fSpeed);

	if (iOffSetMaxY < m_tInfo.vPos.y + iScrollY)
		CScrollMgr_S1::Get_Instance()->Set_ScrollY(-m_fSpeed);
}

void CPlayer_S1::Cursor_Render(HDC hDC)
{
	int		iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int		iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	HBRUSH myBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
	HBRUSH oldBrush = (HBRUSH)SelectObject(hDC, myBrush);

	HPEN myPen = CreatePen(PS_SOLID, 10, RGB(255, 150, 5));
	HPEN OldPen = (HPEN)SelectObject(hDC, myPen);

	D3DXVECTOR3 CENTOR_T = (m_vAPoint[POINT_L_T] + m_vAPoint[POINT_R_T]) * 0.5f;
	D3DXVECTOR3 CENTOR_B = (m_vAPoint[POINT_L_B] + m_vAPoint[POINT_R_B]) * 0.5f;
	D3DXVECTOR3 CENTOR_M = (CENTOR_T + CENTOR_B) * 0.5f;

	D3DXVECTOR3 CURSOR_1 = (m_vAPoint[POINT_L_B] + CENTOR_B) * 0.5f;
	D3DXVECTOR3 CURSOR_2 = (CENTOR_B + m_vAPoint[POINT_R_B]) * 0.5f;
	D3DXVECTOR3 CURSOR_3 = (CENTOR_M + CENTOR_B) * 0.5f;

	MoveToEx(hDC, CENTOR_T.x + iScrollX, CENTOR_T.y + iScrollY, nullptr);
	LineTo(hDC, CURSOR_1.x + iScrollX, CURSOR_1.y + iScrollY);
	LineTo(hDC, CURSOR_3.x + iScrollX, CURSOR_3.y + iScrollY);
	LineTo(hDC, CURSOR_2.x + iScrollX, CURSOR_2.y + iScrollY);
	LineTo(hDC, CENTOR_T.x + iScrollX, CENTOR_T.y + iScrollY);

	SelectObject(hDC, oldBrush);
	DeleteObject(myBrush);

	SelectObject(hDC, OldPen);
	DeleteObject(myPen);

}


void CPlayer_S1::Render(HDC hDC)
{
	int		iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int		iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	HDC		hMemDC = CBmpMgr_S1::Get_Instance()->Find_Img(L"Char");

	if (CPlayer_S1::Collider_Mode == true) {
		ColliderRender(hDC, m_vCOLPoint[POINT_L_T], m_vCOLPoint[POINT_R_T],
						m_vCOLPoint[POINT_R_B], m_vCOLPoint[POINT_L_B]);

		TCHAR	szBuff[32] = L"";
		swprintf_s(szBuff, L"Y��ǥ : %d", (int)m_tInfo.vPos.y);
		TextOut(hDC, m_vPlayer[POINT_L_T].x + iScrollX, m_vPlayer[POINT_L_T].y - 50 + iScrollY, szBuff, lstrlen(szBuff));

		TCHAR	szBuff2[32] = L"";
		swprintf_s(szBuff2, L"X��ǥ : %d", (int)m_tInfo.vPos.x);
		TextOut(hDC, m_vPlayer[POINT_L_T].x + iScrollX, m_vPlayer[POINT_L_T].y - 30 + iScrollY, szBuff2, lstrlen(szBuff2));
	}

	GdiTransparentBlt(hDC,
	(int)m_vPlayer[POINT_L_T].x + iScrollX, (int)m_vPlayer[POINT_L_T].y + iScrollY,
	100, 100, hMemDC,	m_tFrame.iFrameStart * 100, m_tFrame.iMotion * 100,
	100, 100, RGB(195, 134, 255));
	
	Cursor_Render(hDC);
}

void CPlayer_S1::Release()
{
}
