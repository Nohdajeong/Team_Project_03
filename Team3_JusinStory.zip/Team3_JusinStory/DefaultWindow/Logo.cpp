#include "stdafx.h"
#include "Logo.h"
#include "BmpMgr_S3.h"
#include "KeyMgr_S1.h"
#include "SceneMgr.h"

CLogo::CLogo()
{
}

CLogo::~CLogo()
{
	Release();
}

void CLogo::Initialize()
{
	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/Start.bmp", L"TitleLogo");
}

void CLogo::Update()
{
	if (CKeyMgr_S1::Get_Instance()->Key_Pressing('P')) {
		CSceneMgr::Get_Instance()->Scene_Change(SC_STAGE1);
	}
}

void CLogo::Late_Update()
{
	
}

void CLogo::Render(HDC hDC)
{
	HDC		hLogoDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"TitleLogo");

	BitBlt(hDC, 0, 0, 600, 800, hLogoDC, 0, 0, SRCCOPY);
}

void CLogo::Release()
{
	CBmpMgr_S3::Get_Instance()->Destroy_Instance();
}
