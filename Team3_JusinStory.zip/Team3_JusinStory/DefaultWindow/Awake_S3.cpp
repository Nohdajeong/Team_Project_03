#include "stdafx.h"
#include "Awake_S3.h"
#include "ObjMgr_S3.h"
#include "BmpMgr_S3.h"
#include "AbstractFactory_S3.h"
#include "Monster_S3.h"

CAwake_S3::CAwake_S3() : m_ePreState(STATE_END), m_eCurState(IDLE)
{
}

CAwake_S3::~CAwake_S3()
{
	Release();
}

void CAwake_S3::Initialize(void)
{
	m_dwTime = GetTickCount();

	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/Monster.bmp", L"Wake");
	m_pFrameKey = L"Wake";
	
	m_tFrame.iFrameStart = 0;
	m_tFrame.iFrameEnd = 1;
	m_tFrame.iMotion = 0;
	m_tFrame.dwSpeed = 256;
	m_tFrame.dwTime = GetTickCount();
}

int CAwake_S3::Update(void)
{
	if (m_bDead) {
		return OBJ_DEAD;
	}
		
	__super::Move_Frame();
	return OBJ_NOEVENT;
}

void CAwake_S3::Late_Update(void)
{
	if (m_dwTime + 2500 < GetTickCount()) {
		m_bDead = true;
		CObjMgr_S3::Get_Instance()->Add_Object(MONSTER, Sleep());
		m_dwTime = GetTickCount();
	}
}

void CAwake_S3::Render(HDC hDC)
{
	HDC		hMemDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"Wake");
	GdiTransparentBlt(hDC,
		(int)m_tInfo.vPos.x,
		(int)m_tInfo.vPos.y,
		46,
		50,
		hMemDC,
		m_tFrame.iFrameStart * 46,
		m_tFrame.iMotion * 50,
		46,
		50,
		RGB(255, 0, 4));
}


void CAwake_S3::Release(void)
{
}

CObj_S3* CAwake_S3::Sleep(void)
{
	CObj_S3* pWake = CAbstractFactory_S3<CMonster_S3>::Create((float)m_tInfo.vPos.x + 75.f, (float)m_tInfo.vPos.y + 10.f);
	return pWake;
}
