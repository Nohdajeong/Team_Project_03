#pragma once
#include "Scene.h"
#include "Define.h"
#include "Player_S3.h"
#include "Monster_S3.h"

class CStage3 :
	public CScene
{
public:
			 CStage3();
	virtual ~CStage3();

public:
	virtual void Initialize() override;
	virtual void Update() override;
	virtual void Late_Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

private:
	HDC		m_hDC;
	TCHAR   szBuff[100] = L"";
	DWORD				m_dwTime;
};

