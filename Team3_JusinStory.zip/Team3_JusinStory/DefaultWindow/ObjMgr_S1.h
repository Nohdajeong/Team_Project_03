#pragma once

#include "Define.h"
#include "Obj_S1.h"

class CObjMgr_S1
{
private:
	CObjMgr_S1();
	~CObjMgr_S1();

public:
	CObj_S1* Get_Player() { return m_ObjList[PLAYER].front(); }
	list<CObj_S1*> Get_OBJLIST(OBJID eID) {
		if (m_ObjList[eID].empty()) {
			list<CObj_S1*> emptyList;
			return emptyList;
		}
		else { return m_ObjList[eID]; }
	}

public:
	void		Add_Object(OBJID eID, CObj_S1* pInstance);
	int			Update();
	void		Late_Update();
	void		Render(HDC hDC);
	void		Release();

	void		Delete_ID(OBJID eID);

public:
	static CObjMgr_S1* Get_Instance()
	{
		if (!m_pInstance)
		{
			m_pInstance = new CObjMgr_S1;
		}

		return m_pInstance;
	}
	static void		Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}

private:
	list<CObj_S1*>	m_ObjList[OBJID_END];
	list<CObj_S1*>	m_RenderList[RENDER_END];

	static CObjMgr_S1* m_pInstance;

	CObj_S1* m_pPlayer;
	CObj_S1* m_pTrash;
};
