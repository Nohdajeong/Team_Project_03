#pragma once
#include "Obj_S1.h"

class CCar_S1 :
    public CObj_S1
{
public:
	CCar_S1();
	virtual ~CCar_S1();

public:
	// CObj��(��) ���� ��ӵ�
	virtual void Initialize() override;
	virtual int Update() override;
	virtual void Late_Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

	void Set_TYPE(CAR_TYPE eType) { m_Type = eType; };
	void Set_TIMING(int eTiming) { m_Timing = eTiming; };


public:
	//�� 4�� ��
	D3DXVECTOR3 m_vCar[POINT_END];
	D3DXVECTOR3	m_vOriginCar[POINT_END];

	D3DXVECTOR3 m_vCar_COL[POINT_END];
	D3DXVECTOR3	m_vOriginCar_COL[POINT_END];

	D3DXMATRIX matAPoint_World;


protected:
	float		m_fAngle;
	float		m_magni;
	CAR_TYPE	m_Type;

	TCHAR*		m_FrameKey;
	int			m_Fixcel;

	float		m_Car_fcx;
	float		m_Car_fcy;
	int			m_Timing;
};

