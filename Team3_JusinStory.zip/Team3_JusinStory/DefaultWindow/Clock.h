#pragma once
#include "S4_Obj.h"
class CClock :
    public S4_Obj
{
public:
             CClock();
    virtual ~CClock();

public:

    virtual void Initialize()       override;
    virtual int  Update()           override;
    virtual void Late_Update()      override;
    virtual void Render(HDC hDC)    override;
    virtual void Release()          override;


private:
    D3DXVECTOR3 m_vCenterDot;
    INFO m_vHourHand;
    INFO m_vOriginHour;

    INFO m_vMinuteHand;
    INFO m_vOriginMinute;

    float m_fHourDistance;
    float m_fHourAngle;
    
    float m_fMinuteDistance;
    float m_fMinuteAngle;

    D3DXMATRIX matScale;
    D3DXMATRIX matRotZ;
    D3DXMATRIX matTrans;

    ULONGLONG   m_ulHourDelay;
    ULONGLONG   m_ulMinuteDelay;

    SYSTEMTIME time;
};

