#pragma once
#include "S4_Obj.h"

class S4_CollisionMgr
{
public:
	S4_CollisionMgr();
	~S4_CollisionMgr();

public:
	static	bool	OBB_CollisionEx(S4_Obj* Obj1, S4_Obj* Obj2);
};

