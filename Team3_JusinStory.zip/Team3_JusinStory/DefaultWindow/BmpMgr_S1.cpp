#include "stdafx.h"
#include "BmpMgr_S1.h"

CBmpMgr_S1* CBmpMgr_S1::m_pInstance = nullptr;

CBmpMgr_S1::CBmpMgr_S1()
{
}


CBmpMgr_S1::~CBmpMgr_S1()
{
	Release();
}

void CBmpMgr_S1::Insert_Bmp(const TCHAR* pFilePath, const TCHAR* pImgKey)
{
	auto iter = find_if(m_mapBit.begin(), m_mapBit.end(), CTag_Finder(pImgKey));

	if (iter == m_mapBit.end())
	{
		CBitMap_S1* pBmp = new CBitMap_S1;
		pBmp->Load_Bmp(pFilePath);

		m_mapBit.insert({ pImgKey, pBmp });
	}


}

HDC CBmpMgr_S1::Find_Img(const TCHAR* pImgKey)
{
	auto iter = find_if(m_mapBit.begin(), m_mapBit.end(), CTag_Finder(pImgKey));

	if (iter == m_mapBit.end())
		return nullptr;

	return iter->second->Get_MemDC();
}

void CBmpMgr_S1::Release()
{
	for_each(m_mapBit.begin(), m_mapBit.end(), CDeleteMap());
	m_mapBit.clear();
}
