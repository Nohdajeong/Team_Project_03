#include "stdafx.h"
#include "Player_S3.h"
#include "ObjMgr_S3.h"
#include "BmpMgr_S3.h"
#include "Monster_S3.h"

CPlayer_S3::CPlayer_S3() :m_fAngle(0), bCheck(false)
{
}

CPlayer_S3::~CPlayer_S3()
{
	Release();
}

void CPlayer_S3::Initialize()
{
	m_tInfo.vPos = { 600.f, 300.f, 0.f };
	m_vPoint[0] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vPoint[1] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y - 50.f, 0.f };
	m_vPoint[2] = { m_tInfo.vPos.x + 50.f, m_tInfo.vPos.y + 50.f, 0.f };
	m_vPoint[3] = { m_tInfo.vPos.x - 50.f, m_tInfo.vPos.y + 50.f, 0.f };

	m_vGunPoint[0] = { m_tInfo.vPos.x + 30.f , m_tInfo.vPos.y - 500.f, 0.f };
	m_vGunPoint[1] = { m_tInfo.vPos.x - 30.f , m_tInfo.vPos.y - 500.f, 0.f };
	m_vOriginGunPoint[0] = m_vGunPoint[0];
	m_vOriginGunPoint[1] = m_vGunPoint[1];

	m_vPlayerPoint = { m_tInfo.vPos.x, m_tInfo.vPos.y - 200.f, 0.f };
	m_vOriginPlayerPoint = m_vPlayerPoint;

	for (int i = 0; i < 4; ++i) {
		m_vOriginPoint[i] = m_vPoint[i];
	}

	m_fSpeed = 5.f;
	m_eRender = GAMEOBJECT;

	

	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/Teacher_IDLE.bmp", L"Player");
	m_pFrameKey = L"Player";
	m_tFrame.iFrameStart = 0;
	m_tFrame.iFrameEnd = 2;
	m_tFrame.iMotion = 0;
	m_tFrame.dwSpeed = 128;
	m_tFrame.dwTime = GetTickCount();
}

int CPlayer_S3::Update()
{
	m_tInfo.vPos.y += m_fSpeed;
	if (m_tInfo.vPos.y <= 100.f) {
		m_fSpeed *= -1.f ;
	}
	if (m_tInfo.vPos.y >= 400.f) {
		m_fSpeed *= -1.f;
	}

	Key_Input();
	D3DXMATRIX matScale, matRotZ, matTrans;
	D3DXMatrixScaling(&matScale, -1.f, 1.f, 1.f);
	D3DXMatrixRotationZ(&matRotZ, m_fAngle);
	D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

	m_tInfo.matWorld = matScale * matRotZ * matTrans;

	for (int i = 0; i < 4; ++i) {
		m_vPoint[i] = m_vOriginPoint[i];
		m_vPoint[i] -= {600.f, 300.f, 0.f};

		D3DXVec3TransformCoord(&m_vPoint[i], &m_vPoint[i], &m_tInfo.matWorld);
	}

	for (int i = 0; i < 2; ++i) {
		m_vGunPoint[i] = m_vOriginGunPoint[i];
		m_vGunPoint[i] -= { 600.f, 300.f, 0.f};

		D3DXVec3TransformCoord(&m_vGunPoint[i], &m_vGunPoint[i], &m_tInfo.matWorld);
	}

	m_vPlayerPoint = m_vOriginPlayerPoint;
	m_vPlayerPoint -= {600.f, 300.f, 0.f};
	D3DXVec3TransformCoord(&m_vPlayerPoint, &m_vPlayerPoint, &m_tInfo.matWorld);




	D3DXVECTOR3		vGunDir[2];
	vGunDir[0] = m_vGunPoint[0] - m_tInfo.vPos;
	vGunDir[1] = m_vGunPoint[1] - m_tInfo.vPos;
	D3DXVec3Normalize(&vGunDir[0], &vGunDir[0]);
	D3DXVec3Normalize(&vGunDir[1], &vGunDir[1]);
	float fDot = D3DXVec3Dot(&vGunDir[0], &vGunDir[1]);
	fAngle = acos(fDot) / 2;
	if (m_tInfo.vPos.y < m_vGunPoint[0].y && m_tInfo.vPos.y < m_vGunPoint[1].y) {
		fAngle = 2 * D3DX_PI - fAngle;
	}
	fAngle = cos(fAngle);

	if (bCheck)
	{
		m_pMonster = CObjMgr_S3::Get_Instance()->Get_Target(MONSTER, this);
		if (m_pMonster) {
			D3DXVECTOR3		vMonsterPoint = m_pMonster->Get_Info().vPos;
			D3DXVECTOR3		vMonsterDir = vMonsterPoint - m_tInfo.vPos;
			D3DXVec3Normalize(&vMonsterDir, &vMonsterDir);

			D3DXVECTOR3		vPlayerDir = m_vPlayerPoint - m_tInfo.vPos;
			D3DXVec3Normalize(&vPlayerDir, &vPlayerDir);
			fMonsterAngle = D3DXVec3Dot(&vMonsterDir, &vPlayerDir);

			if (fMonsterAngle >= fAngle) {
				CObjMgr_S3::Get_Instance()->Get_Target(MONSTER, this)->Set_Awake(true);
			}
		}
	}

	__super::Move_Frame();
	return OBJ_NOEVENT;
}

void CPlayer_S3::Late_Update()
{
}

void CPlayer_S3::Render(HDC hDC)
{
	
	MoveToEx(hDC, (int)m_tInfo.vPos.x, (int)m_tInfo.vPos.y, nullptr);
	LineTo(hDC, (int)m_vGunPoint[0].x, (int)m_vGunPoint[0].y);

	MoveToEx(hDC, (int)m_tInfo.vPos.x, (int)m_tInfo.vPos.y, nullptr);
	LineTo(hDC, (int)m_vGunPoint[1].x, (int)m_vGunPoint[1].y);
	//LineTo(hDC, (int)m_vGunPoint[0].x, (int)m_vGunPoint[0].y);
	

	HDC		hMemDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"Player");
	GdiTransparentBlt(hDC,
		(int)m_tInfo.vPos.x-25,
		(int)m_tInfo.vPos.y-27,
		50,
		75,
		hMemDC,
		m_tFrame.iFrameStart * 50,
		m_tFrame.iMotion * 75,
		50,
		75,
		RGB(195, 134, 255));
}

void CPlayer_S3::Release()
{
}

void CPlayer_S3::Key_Input()
{
	if (GetAsyncKeyState('Z')) {
		m_fAngle -= D3DXToRadian(1.f);
	}
	if (GetAsyncKeyState('X')) {
		m_fAngle += D3DXToRadian(1.f);
	}
	if (GetAsyncKeyState(VK_SPACE)) { //key_pressing���� �ٲ����
		bCheck = true;
	}
	else {
		bCheck = false;
	}
}