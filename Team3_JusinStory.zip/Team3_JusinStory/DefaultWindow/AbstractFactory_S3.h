#pragma once

#include "Obj_S3.h"

template<typename T>
class CAbstractFactory_S3
{
public:
	CAbstractFactory_S3() {}
	~CAbstractFactory_S3() {}

public:
	static CObj_S3* Create()
	{
		CObj_S3* pObj_S3 = new T;
		pObj_S3->Initialize();

		return pObj_S3;
	}

	static CObj_S3* Create(float _fX, float _fY)
	{
		CObj_S3* pObj_S3 = new T;
		pObj_S3->Initialize();
		pObj_S3->Set_Pos(_fX, _fY);
		return pObj_S3;
	}

};

