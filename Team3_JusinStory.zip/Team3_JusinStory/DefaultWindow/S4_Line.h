#pragma once

#include "Define.h"
#include "S4_Obj.h"

class S4_CLine : public S4_Obj
{
public:
	S4_CLine();
	S4_CLine(LINE& tLine);
	S4_CLine(LINEPOINT& _tpoint);
	~S4_CLine();

public:
	virtual void Initialize() override;
	virtual int  Update() override;
	virtual void Late_Update() override;
	virtual void Release() override;

	LINE		Get_Info() { return m_tInfo; }

public:
	void		Render(HDC hDC);

private:
	LINE		m_tInfo;


};

