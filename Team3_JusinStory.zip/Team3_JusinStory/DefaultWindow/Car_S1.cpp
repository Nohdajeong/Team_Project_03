#include "stdafx.h"
#include "Car_S1.h"
#include "BmpMgr_S1.h"
#include "ScrollMgr_S1.h"
#include "Player_S1.h"

CCar_S1::CCar_S1() : m_fAngle(0.f), m_magni(1.f), m_Type(CAR_TYPE::CAR_END), m_FrameKey(),
m_Car_fcx(0.f), m_Car_fcy(0.f), m_Timing(0)
{
}

CCar_S1::~CCar_S1()
{
}

void CCar_S1::Initialize()
{
	CBmpMgr_S1::Get_Instance()->Insert_Bmp(L"../Data/car2.bmp", L"CAR");
	CBmpMgr_S1::Get_Instance()->Insert_Bmp(L"../Data/bus1.bmp", L"BUS");

	switch (m_Type) {
	case CAR_TYPE::CAR_1:
		m_tFrame.iFrameStart = 0;
		m_tFrame.iMotion = 0;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::CAR_2:
		m_tFrame.iFrameStart = 0;
		m_tFrame.iMotion = 1;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::CAR_3:
		m_tFrame.iFrameStart = 0;
		m_tFrame.iMotion = 2;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::CAR_4:
		m_tFrame.iFrameStart = 1;
		m_tFrame.iMotion = 0;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::CAR_5:
		m_tFrame.iFrameStart = 1;
		m_tFrame.iMotion = 1;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::CAR_6:
		m_tFrame.iFrameStart = 1;
		m_tFrame.iMotion = 2;
		m_FrameKey = L"CAR";
		break;

	case CAR_TYPE::BUS_1:
		m_tFrame.iFrameStart = 0;
		m_tFrame.iMotion = 0;
		m_FrameKey = L"BUS";
		break;

	case CAR_TYPE::BUS_2:
		m_tFrame.iFrameStart = 0;
		m_tFrame.iMotion = 1;
		m_FrameKey = L"BUS";
		break;
	
	}

	if (m_FrameKey == L"CAR") { 
		m_vCar[POINT_L_T] = { m_tInfo.vPos.x - 78.5f, m_tInfo.vPos.y - 45.f, 0.f };
		m_vCar[POINT_R_T] = { m_tInfo.vPos.x + 78.5f, m_tInfo.vPos.y - 45.f, 0.f };
		m_vCar[POINT_R_B] = { m_tInfo.vPos.x + 78.5f, m_tInfo.vPos.y + 45.f, 0.f };
		m_vCar[POINT_L_B] = { m_tInfo.vPos.x - 78.5f, m_tInfo.vPos.y + 45.f, 0.f };
		m_Fixcel = 26;
		m_Car_fcx = 156.f;
		m_Car_fcy = 90.f;
	}
	else if (m_FrameKey == L"BUS") { 
		m_vCar[POINT_L_T] = { m_tInfo.vPos.x - 125.f, m_tInfo.vPos.y - 39.f, 0.f };
		m_vCar[POINT_R_T] = { m_tInfo.vPos.x + 125.f, m_tInfo.vPos.y - 39.f, 0.f };
		m_vCar[POINT_R_B] = { m_tInfo.vPos.x + 125.f, m_tInfo.vPos.y + 39.f, 0.f };
		m_vCar[POINT_L_B] = { m_tInfo.vPos.x - 125.f, m_tInfo.vPos.y + 39.f, 0.f };
		m_Fixcel = 11; 
		m_Car_fcx = 250.f;
		m_Car_fcy = 78.f;
	}

	for (int i = 0; i < 4; ++i)
	{
		m_vOriginCar[i] = m_vCar[i];
		m_vCar_COL[i] = m_vCar[i];
		m_vOriginCar_COL[i] = m_vCar[i];
	}

	for (int i = 0; i < 4; ++i)
	{
		Push_vPoint(m_vCar_COL[i]);
		Push_m_VOriginPoint(m_vOriginCar_COL[i]);
	}

}

int CCar_S1::Update()
{
	if (m_bDead == true) { return OBJ_DEAD;	}

	if (m_dwtime + m_Timing < (DWORD)GetTickCount64())
	{
		D3DXMATRIX matScale_A, matTrans_A;

		D3DXMatrixScaling(&matScale_A, 1.f * m_magni, 1.f * m_magni, 1.f * m_magni);
		if (m_eDIr == RIGHT)
			D3DXMatrixTranslation(&matTrans_A, m_eDIr * One_Block, 0.f, 0.f);
		else if (m_eDIr == LEFT)
			D3DXMatrixTranslation(&matTrans_A, m_eDIr * One_Block, 0.f, 0.f);

		matAPoint_World = matScale_A * matTrans_A;

		for (int i = POINT_L_T; i < POINT_END; ++i)
		{		
			m_vCar[i] = m_vOriginCar[i];
			m_vCar[i] -= { Start_X, Start_Y, 0.f };
		}

		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &matAPoint_World);

		if (m_FrameKey == L"CAR") {
			m_vCar[POINT_L_T] = { m_tInfo.vPos.x - 78.5f, m_tInfo.vPos.y - 45.f, 0.f };
			m_vCar[POINT_R_T] = { m_tInfo.vPos.x + 78.5f, m_tInfo.vPos.y - 45.f, 0.f };
			m_vCar[POINT_R_B] = { m_tInfo.vPos.x + 78.5f, m_tInfo.vPos.y + 45.f, 0.f };
			m_vCar[POINT_L_B] = { m_tInfo.vPos.x - 78.5f, m_tInfo.vPos.y + 45.f, 0.f };
			m_Fixcel = 26;
		}
		else if (m_FrameKey == L"BUS") {
			m_vCar[POINT_L_T] = { m_tInfo.vPos.x - 125.f, m_tInfo.vPos.y - 39.f, 0.f };
			m_vCar[POINT_R_T] = { m_tInfo.vPos.x + 125.f, m_tInfo.vPos.y - 39.f, 0.f };
			m_vCar[POINT_R_B] = { m_tInfo.vPos.x + 125.f, m_tInfo.vPos.y + 39.f, 0.f };
			m_vCar[POINT_L_B] = { m_tInfo.vPos.x - 125.f, m_tInfo.vPos.y + 39.f, 0.f };
			m_Fixcel = 11;
		}

		for (int i = 0; i < 4; ++i) {
			m_vCar_COL[i] = m_vCar[i];
			m_vOriginCar_COL[i] = m_vCar[i];
		}
		for (int i = 0; i < 4; ++i) {
			m_vecPoint[i] = m_vCar_COL[i];
			m_vecOriginPoint[i] = m_vOriginCar_COL[i];
		}

		m_dwtime = (DWORD)GetTickCount64();
	}
	

	return OBJ_NOEVENT;
}

void CCar_S1::Late_Update()
{
	D3DXMATRIX matTrans_A;
	if (m_tInfo.vPos.x > 2175.f) { 
		m_tInfo.vPos.x = -200.f; 
		D3DXMatrixTranslation(&matTrans_A, -2375.f, 0.f, 0.f);
		for (int i = 0; i < 4; ++i) {
			D3DXVec3TransformCoord(&m_vCar[i], &m_vCar[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vOriginCar[i], &m_vOriginCar[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vCar_COL[i], &m_vCar_COL[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vOriginCar_COL[i], &m_vOriginCar_COL[i], &matTrans_A);
		}
	}

	if (m_tInfo.vPos.x < -210.f) {
		m_tInfo.vPos.x = 2165.f;
		D3DXMatrixTranslation(&matTrans_A, 2375.f, 0.f, 0.f);
		for (int i = 0; i < 4; ++i) {
			D3DXVec3TransformCoord(&m_vCar[i], &m_vCar[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vOriginCar[i], &m_vOriginCar[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vCar_COL[i], &m_vCar_COL[i], &matTrans_A);
			D3DXVec3TransformCoord(&m_vOriginCar_COL[i], &m_vOriginCar_COL[i], &matTrans_A);
		}
	}
}

void CCar_S1::Render(HDC hDC)
{ 
	int		iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int		iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	HDC		hMemDC = CBmpMgr_S1::Get_Instance()->Find_Img(m_FrameKey);

	if (CPlayer_S1::Collider_Mode == true) {
		ColliderRender(hDC, m_vCar_COL[POINT_L_T], m_vCar_COL[POINT_R_T],
			m_vCar_COL[POINT_R_B], m_vCar_COL[POINT_L_B]);
	}

	GdiTransparentBlt(hDC,
		(int)m_vCar[POINT_L_T].x + iScrollX, (int)m_vCar[POINT_L_T].y + iScrollY,
		(int)m_Car_fcx, (int)m_Car_fcy, hMemDC, (int)m_tFrame.iFrameStart * m_Car_fcx, 
		(int)m_tFrame.iMotion * (m_Car_fcy + m_Fixcel),
		m_Car_fcx, m_Car_fcy, RGB(255, 0, 255));
}

void CCar_S1::Release()
{
}
