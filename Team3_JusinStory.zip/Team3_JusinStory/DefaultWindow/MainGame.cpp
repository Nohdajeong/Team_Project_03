#include "stdafx.h"
#include "MainGame.h"
#include "BmpMgr_S1.h"
#include "SceneMgr.h"
#include "SoundMgr.h"

CMainGame::CMainGame()
{
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize(void)
{
	m_DC = GetDC(g_hWnd);

	CSceneMgr::Get_Instance()->Scene_Change(SC_LOGO);
	CBmpMgr_S1::Get_Instance()->Insert_Bmp(L"../Data/Map.bmp", L"bmpMAP");
	CBmpMgr_S1::Get_Instance()->Insert_Bmp(L"../Data/Map.bmp", L"BackMAP");
	CSoundMgr::Get_Instance()->Initialize();
}

void CMainGame::Update(void)
{
	CSceneMgr::Get_Instance()->Update();
}

void CMainGame::Late_Update(void)
{
	CSceneMgr::Get_Instance()->Late_Update();

}

void CMainGame::Render(void)
{
	HDC		hMemDC = CBmpMgr_S1::Get_Instance()->Find_Img(L"BackMAP");

	CSceneMgr::Get_Instance()->Render(hMemDC);

	BitBlt(m_DC, 0, 0, WINCX, WINCY, hMemDC, 0, 0, SRCCOPY);
}

void CMainGame::Release(void)
{
	ReleaseDC(g_hWnd, m_DC);
	CSoundMgr::Get_Instance()->Destroy_Instance();
}
