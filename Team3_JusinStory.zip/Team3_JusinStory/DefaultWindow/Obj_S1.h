#pragma once
#include "Define.h"

class CObj_S1
{
public:
	CObj_S1();
	virtual ~CObj_S1();

public:
	const INFO& Get_Info() const { return m_tInfo; }
	INFO&		Get_Info() { return m_tInfo; }
	void		Set_Pos(float _x, float _y)  
	{ m_tInfo.vPos.x = _x;
	  m_tInfo.vPos.y = _y;
	}

public:
	virtual void		Initialize()	PURE;
	virtual int			Update()		PURE;
	virtual void		Late_Update()	PURE;
	virtual void		Render(HDC hDC)	PURE;
	virtual void		Release()		PURE;

	void		Push_vPoint(D3DXVECTOR3 _Point) { m_vecPoint.push_back({ _Point.x, _Point.y, 0.f }); }
	void		Push_m_VOriginPoint(D3DXVECTOR3 _Point) { m_vecOriginPoint.push_back({ _Point.x, _Point.y, 0.f }); }
	
	void		Set_Dead() { m_bDead = true; }
	void		Set_Dir(DIRECTION eDir) { m_eDIr = eDir; }
	
	vector<D3DXVECTOR3> Get_vPoint(void) { return m_vecPoint; }
	vector<D3DXVECTOR3> Get_vOriginPoint(void) { return m_vecOriginPoint; }

protected:
	void		Move_Frame();
	void		ColliderRender(HDC hDC, D3DXVECTOR3 _LT, D3DXVECTOR3 _RT, D3DXVECTOR3 _RB, D3DXVECTOR3 _LB);
	
protected:
	INFO		m_tInfo;
	float		m_fSpeed;
	DWORD		m_dwtime;

	FRAME		m_tFrame;
	bool		m_bDead;
	DIRECTION   m_eDIr;

	vector<D3DXVECTOR3> m_vecPoint;
	vector<D3DXVECTOR3> m_vecOriginPoint;
};


