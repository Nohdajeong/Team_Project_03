#pragma once
#include "S4_Obj.h"
class S4_CCup :
    public S4_Obj
{
public:
             S4_CCup();
    virtual ~S4_CCup();

public:
    virtual void Initialize() override;
    virtual int Update() override;
    virtual void Late_Update() override;
    virtual void Render(HDC hDC) override;
    virtual void Release() override;


};

