#include "stdafx.h"
#include "S4_Line.h"


S4_CLine::S4_CLine()
{
}

S4_CLine::S4_CLine(LINE& tLine)
	:m_tInfo(tLine)
{
}

S4_CLine::S4_CLine(LINEPOINT& _tpoint)
	: m_tInfo(_tpoint)
{
}


S4_CLine::~S4_CLine()
{
	Release();
}


void S4_CLine::Render(HDC hDC)
{
	MoveToEx(hDC, int(m_tInfo.tpoint.vStartLine.x), (int)m_tInfo.tpoint.vStartLine.y, nullptr);
	LineTo(hDC, int(m_tInfo.tpoint.vEndLine.x), (int)m_tInfo.tpoint.vEndLine.y);
}



void S4_CLine::Initialize()
{
	
}

int S4_CLine::Update()
{
	return OBJ_NOEVENT;
}

void S4_CLine::Late_Update()
{
}

void S4_CLine::Release()
{
}


