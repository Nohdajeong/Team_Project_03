#pragma once
#include "BitMap_S3.h"

class CBmpMgr_S3
{
private:
	CBmpMgr_S3();
	~CBmpMgr_S3();

public:
	void		Insert_Bmp(const TCHAR* pFilePath, const TCHAR* pImgKey);
	HDC			Find_Img(const TCHAR* pImgKey);
	void		Release();

public:
	static CBmpMgr_S3* Get_Instance()
	{
		if (!m_pInstance)
		{
			m_pInstance = new CBmpMgr_S3;
		}

		return m_pInstance;
	}
	static void		Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}

private:
	static CBmpMgr_S3* m_pInstance;
	map<const TCHAR*, CBitMap_S3*>			m_mapBit;

};

