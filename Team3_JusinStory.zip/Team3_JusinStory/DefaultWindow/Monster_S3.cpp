#include "stdafx.h"
#include "Monster_S3.h"
#include "ObjMgr_S3.h"
#include "Player_S3.h"
#include "BmpMgr_S3.h"
#include "AbstractFactory_S3.h"
#include "Awake_S3.h"

CMonster_S3::CMonster_S3()
{
}

CMonster_S3::~CMonster_S3()
{
	Release();
}

void CMonster_S3::Initialize()
{
	m_tInfo.vPos = { 100.f, 500.f, 0.f };
	m_bDead = false;
	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/zzz.bmp", L"zzz");
}

int CMonster_S3::Update()
{
	if (m_bDead) {
		return OBJ_DEAD;
	}

	return OBJ_NOEVENT;
}

void CMonster_S3::Late_Update()
{
	if (m_bAwake) {
		CObjMgr_S3::Get_Instance()->Add_Object(WAKE_MONSTER, Wake());
		m_bDead = true;
	}
}

void CMonster_S3::Render(HDC hDC)
{

	HDC		hMemDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"zzz");
	GdiTransparentBlt(hDC,
		(int)m_tInfo.vPos.x - 25, (int)m_tInfo.vPos.y - 15, 50, 30, hMemDC, 0, 0, 50, 30, RGB(255, 0, 4));
}

void CMonster_S3::Release()
{
}

CObj_S3* CMonster_S3::Wake(void)
{
	CObj_S3* pWake = CAbstractFactory_S3<CAwake_S3>::Create((float)m_tInfo.vPos.x - 75.f, (float)m_tInfo.vPos.y - 10.f);
	return pWake;
}
