#pragma once

#include "S4_Line.h"
#include "S4_Obj.h"

class S4_CLineMgr
{
private:
	S4_CLineMgr();
	~S4_CLineMgr();

public:
	//bool		Collision_Line(float& fX, float* pY);
	bool		Check_Collision(S4_Obj& Obj);
	bool		Collision_VectorLine(S4_Obj* CObj, float* fX, float* fY);
	void		Load_Line();
	void		Save_Line();
	float		DistanceFromPointToLine(const D3DXVECTOR3& start, const D3DXVECTOR3& end, const D3DXVECTOR3& point, D3DXVECTOR3& closestPoint);
	void		CollisionResponse(S4_Obj& Obj, const D3DXVECTOR3& Collision_Normal, float penetrationDepth);
	D3DXVECTOR3 ClosestPointOnLine(const D3DXVECTOR3& lineStart, const D3DXVECTOR3& lineEnd, const D3DXVECTOR3& point)
	{
		D3DXVECTOR3 lineDirection = lineEnd - lineStart;
		D3DXVECTOR3 pointDirection = point - lineStart;

		float lineLength = D3DXVec3Length(&lineDirection);
		float dotProduct = D3DXVec3Dot(&pointDirection, &lineDirection);

		if (lineLength > 0.0f)
		{
			float t = dotProduct / (lineLength * lineLength);
			if (t < 0.0f)
				t = 0.0f;
			else if (t > 1.0f)
				t = 1.0f;

			return lineStart + t * lineDirection;
		}

		// ������ ���̰� 0�̸� ������ �������� ������ ��ġ�� ��ȯ
		return lineStart;
	}

public:
	void		Initialize();
	int			Update();
	void		Late_Update();
	void		Render(HDC hDC);
	void		Release();

public:
	static S4_CLineMgr* Get_Instance()
	{
		if (!m_pInstance)
		{
			m_pInstance = new S4_CLineMgr;
		}

		return m_pInstance;
	}
	static void		Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}

private:
	list<S4_CLine*>			m_LineList;
	LINEPOINT				m_tLintPoint;
	

	static S4_CLineMgr* m_pInstance;
};

