#include "stdafx.h"
#include "BmpMgr_S3.h"

CBmpMgr_S3* CBmpMgr_S3::m_pInstance = nullptr;

CBmpMgr_S3::CBmpMgr_S3()
{
}


CBmpMgr_S3::~CBmpMgr_S3()
{
	Release();
}

void CBmpMgr_S3::Insert_Bmp(const TCHAR* pFilePath, const TCHAR* pImgKey)
{
	auto iter = find_if(m_mapBit.begin(), m_mapBit.end(), CTag_Finder(pImgKey));

	if (iter == m_mapBit.end())
	{
		CBitMap_S3* pBmp = new CBitMap_S3;
		pBmp->Load_Bmp(pFilePath);

		m_mapBit.insert({ pImgKey, pBmp });
	}


}

HDC CBmpMgr_S3::Find_Img(const TCHAR* pImgKey)
{
	auto iter = find_if(m_mapBit.begin(), m_mapBit.end(), CTag_Finder(pImgKey));

	if (iter == m_mapBit.end())
		return nullptr;

	return iter->second->Get_MemDC();
}

void CBmpMgr_S3::Release()
{
	for_each(m_mapBit.begin(), m_mapBit.end(), CDeleteMap());
	m_mapBit.clear();
}
