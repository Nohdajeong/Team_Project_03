#include "stdafx.h"
#include "Tank.h"
#include "KeyMgr_S1.h"

CTank::CTank():m_fAngle(0), m_fPosinAngle(0)
{
}

CTank::~CTank()
{
	Release();
}

void CTank::Initialize()
{
	m_tInfo.vPos = { 400.f, 300.f , 0.f }; // ����
	m_fSpeed = 5.f;
	m_fAngle = 0.f;

	D3DXMatrixIdentity(&matScale);
	D3DXMatrixIdentity(&matRotate);
	D3DXMatrixIdentity(&matMove);
	
	// ����
	m_fPosinAngle = 0.f;
	m_fPosinDistance = 100.f;
	D3DXMatrixIdentity(&matPosinRotate);
	
}

void CTank::Update()
{
	m_tPosin = { m_tInfo.vPos.x, m_tInfo.vPos.y - m_fPosinDistance, 0.f };

	if (CKeyMgr_S1::Get_Instance()->Key_Pressing(VK_LEFT))
	{
		m_fAngle -= 5.f;
	}
	
	if (CKeyMgr_S1::Get_Instance()->Key_Pressing(VK_RIGHT))
	{
		m_fAngle += 5.f;
	}

	if (CKeyMgr_S1::Get_Instance()->Key_Pressing('A'))
	{
		m_fPosinAngle -= 5.f;
	}

	if (CKeyMgr_S1::Get_Instance()->Key_Pressing('D'))
	{
		m_fPosinAngle += 5.f;
	}


	// �� ��ġ���� �ʱ�ȭ
	vLeftTop = { -50.f , -50.f,  0.f };
	vRightTop = { 50.f , -50.f,  0.f };
	vLeftBottom = { -50.f ,  50.f,  0.f };
	vRightBottom = { 50.f ,  50.f,  0.f };

	// ȸ����� �����
	D3DXMatrixRotationZ(&matRotate, D3DXToRadian(m_fAngle));
	D3DXMatrixRotationZ(&matPosinRotate, D3DXToRadian(m_fPosinAngle));

	// �� ��ġ ���͵鿡�� ȸ�� �� ����
	D3DXVec3TransformNormal(&vLeftTop, &vLeftTop, &matRotate);
	D3DXVec3TransformNormal(&vRightTop, &vRightTop, &matRotate);
	D3DXVec3TransformNormal(&vLeftBottom, &vLeftBottom, &matRotate);
	D3DXVec3TransformNormal(&vRightBottom, &vRightBottom, &matRotate);

	D3DXVec3TransformNormal(&m_tPosin, &m_tPosin, &matPosinRotate);

	m_tPosin.x += m_tInfo.vPos.x;
	m_tPosin.y += m_tInfo.vPos.y - m_fPosinDistance;

	// ���� ��ǥ�� �̵�
	vLeftTop += m_tInfo.vPos;
	vRightTop += m_tInfo.vPos;
	vLeftBottom += m_tInfo.vPos;
	vRightBottom += m_tInfo.vPos;

	// ���� �������� ��ü�� ������ ����. ���� ���Ͱ� ���´�.
	D3DXVECTOR3 vCenter = (vLeftTop + vRightTop) * 0.5f;
	m_tInfo.vDir = vCenter - m_tInfo.vPos;
	D3DXVec3Normalize(&m_tInfo.vDir, &m_tInfo.vDir);

	
	if (CKeyMgr_S1::Get_Instance()->Key_Pressing(VK_UP))
	{
		D3DXMatrixTranslation(&matMove, m_tInfo.vDir.x, m_tInfo.vDir.y, 0); // �̵����
		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &matMove); // �̵����� 
	}

	if (CKeyMgr_S1::Get_Instance()->Key_Pressing(VK_DOWN))
	{
		D3DXMatrixTranslation(&matMove, -m_tInfo.vDir.x, -m_tInfo.vDir.y, 0);
		D3DXVec3TransformCoord(&m_tInfo.vPos, &m_tInfo.vPos, &matMove);
	}

	
}

void CTank::Render(HDC hDC)
{
	MoveToEx(hDC, vLeftTop.x, vLeftTop.y, nullptr);
	
	LineTo(hDC,		   vRightTop.x,	   vRightTop.y);
	LineTo(hDC,		vRightBottom.x,	vRightBottom.y);
	LineTo(hDC,		 vLeftBottom.x,	 vLeftBottom.y);
	LineTo(hDC,		    vLeftTop.x,	    vLeftTop.y); 

	D3DXVECTOR3 vCenter = (vLeftTop + vRightTop) * 0.5f;

	Ellipse(hDC, vCenter.x - 10, vCenter.y - 10, vCenter.x + 10, vCenter.y + 10);

	MoveToEx(hDC, m_tInfo.vPos.x, m_tInfo.vPos.y, nullptr);
	LineTo(hDC, m_tPosin.x, m_tPosin.y);
}

void CTank::Release()
{
}

