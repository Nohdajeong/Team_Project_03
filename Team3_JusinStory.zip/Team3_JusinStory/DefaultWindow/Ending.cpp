#include "stdafx.h"
#include "Ending.h"
#include "BmpMgr_S3.h"
#include "KeyMgr_S1.h"
#include "SceneMgr.h"
#include "SoundMgr.h"

CEnding::CEnding()
{
}

CEnding::~CEnding()
{
	Release();
}

void CEnding::Initialize()
{
	CBmpMgr_S3::Get_Instance()->Insert_Bmp(L"../Resource/success.bmp", L"success");
}

void CEnding::Update()
{
}

void CEnding::Late_Update()
{
}

void CEnding::Render(HDC hDC)
{
	HDC		hLogoDC = CBmpMgr_S3::Get_Instance()->Find_Img(L"success");
	BitBlt(hDC, -80, 0, 900, 600, hLogoDC, 0, 0, SRCCOPY);
}

void CEnding::Release()
{
	CBmpMgr_S3::Get_Instance()->Destroy_Instance();
	CSoundMgr::Get_Instance()->Destroy_Instance();
}
