#pragma once
#include "Scene.h"
#include "S4_Player.h"
#include "Computer.h"
#include "Clock.h"
#include "Cup.h"
#include "AnswerCube.h"

class CStage4 :
	public CScene
{
public:
			 CStage4();
	virtual ~CStage4();

public:
	virtual void Initialize() override;
	virtual void Update() override;
	virtual void Late_Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

public:
	void	Trickery();
	

private:
	S4_Obj* m_pPlayer;
	S4_Obj* m_pComputer;
	S4_Obj* m_pClock;

	S4_Obj* m_pCup[4];
	S4_Obj* m_pAnswerCube;
	bool	m_bEdit;
	bool	m_bStart;

	int		m_iIncrease = 0;

	int iRandom1, iRandom2;
	ULONGLONG	m_ulDelay = GetTickCount64();
};

