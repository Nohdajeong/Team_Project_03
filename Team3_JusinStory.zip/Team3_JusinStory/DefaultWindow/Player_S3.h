#pragma once
#include "Obj_S3.h"

class CPlayer_S3 : public CObj_S3
{
public:
    enum STATE { IDLE };

public:
    CPlayer_S3();
    virtual ~CPlayer_S3();

public:
    virtual void Initialize() override;
    virtual int  Update() override;
    virtual void Late_Update() override;
    virtual void Render(HDC hDC) override;
    virtual void Release() override;

public:
    void		Key_Input();
    void		Set_Monster(CObj_S3* pMonster) { m_pMonster = pMonster; }


private:
    D3DXVECTOR3		m_vPoint[4];
    D3DXVECTOR3		m_vOriginPoint[4];
    D3DXVECTOR3		m_vGunPoint[2];
    D3DXVECTOR3		m_vOriginGunPoint[2];

    float			m_fAngle = 0.f;
    CObj_S3*        m_pMonster;

    D3DXVECTOR3		m_vPlayerPoint;
    D3DXVECTOR3		m_vOriginPlayerPoint;

    float fAngle;
    float fMonsterAngle;
    bool bCheck;

    STATE				m_eCurState;
    STATE				m_ePreState;
};

