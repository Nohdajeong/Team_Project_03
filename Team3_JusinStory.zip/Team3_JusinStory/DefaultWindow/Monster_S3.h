#pragma once
#include "Obj_S3.h"

class CMonster_S3 : public CObj_S3
{
public:
	CMonster_S3();
	virtual ~CMonster_S3();

public:
	virtual void Initialize() override;
	virtual int Update() override;
	virtual void Late_Update() override;
	virtual void Render(HDC hDC) override;
	virtual void Release() override;

private:
	CObj_S3*	Wake(void);

public:
	void		Set_Player(CObj_S3* pPlayer) { m_pPlayer = pPlayer; }

public:
	CObj_S3* m_pPlayer;
};


