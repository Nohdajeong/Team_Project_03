#pragma once
#include "S4_Obj.h"
class S4_Player :
    public S4_Obj
{
public:
    enum STATE { IDLE, WALK, ATTACK, HIT, DEAD, STATE_END };

public:
             S4_Player();
    virtual ~S4_Player();

public:
    virtual void Initialize() override;
    virtual int  Update() override;
    virtual void Late_Update() override;
    virtual void Render(HDC hDC) override;
    virtual void Release() override;

private:
    void           KeyInput();
    void           Motion_Change();
    D3DXVECTOR3    Get_Dir(bool wKey, bool aKey, bool sKey, bool dKey);

private:
    STATE				m_eCurState;
    STATE				m_ePreState;

    bool                UpKey;
    bool                DownKey;
    bool                LeftKey;
    bool                RightKey;

    //D3DXVECTOR3         ColliderPos;
    D3DXMATRIX          ColliderMat;

};

