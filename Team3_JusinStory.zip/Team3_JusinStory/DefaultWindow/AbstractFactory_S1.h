#pragma once

#include "Obj_S1.h"
#include "Car_S1.h"

template<typename T>
class CAbstractFactory
{
public:
	CAbstractFactory() {}
	~CAbstractFactory() {}

public:
	static CObj_S1* Create()
	{
		CObj_S1* pObj = new T;
		pObj->Initialize();

		return pObj;
	}

	static CObj_S1* Create(float _fX, float _fY)
	{
		CObj_S1* pObj = new T;
		pObj->Initialize();
		pObj->Set_Pos(_fX, _fY);

		return pObj;
	}

	static CCar_S1* Create_Car(float _fX, float _fY, CAR_TYPE eType, DIRECTION eDir, int Timing)
	{
		CCar_S1* pCar = new T;
		pCar->Set_Pos(_fX, _fY);
		pCar->Set_Dir(eDir);
		pCar->Set_TYPE(eType);
		pCar->Set_TIMING(Timing);
		pCar->Initialize();

		return pCar;
	}

};

