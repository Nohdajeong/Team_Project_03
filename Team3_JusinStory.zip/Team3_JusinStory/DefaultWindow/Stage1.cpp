#include "stdafx.h"
#include "Stage1.h"
#include "BmpMgr_S1.h"
#include "ObjMgr_S1.h"
#include "ScrollMgr_S1.h"
#include "CollisionMgr_S1.h"
#include "Player_S1.h"
#include "Trash_S1.h"
#include "Car_S1.h"
#include "AbstractFactory_S1.h"
#include "KeyMgr_S1.h"
#include "SceneMgr.h"
#include "SoundMgr.h"

CStage1::CStage1()
{
}

CStage1::~CStage1()
{
}

void CStage1::Initialize()
{
	CScrollMgr_S1::Get_Instance()->Setting_first_ScrollX_ver(-300);
	CScrollMgr_S1::Get_Instance()->Setting_first_ScrollY_ver(-1790);

	CObjMgr_S1::Get_Instance()->Add_Object(PLAYER, CAbstractFactory<CPlayer_S1>::Create(Start_X, Start_Y));
	CObjMgr_S1::Get_Instance()->Add_Object(TRASH, CAbstractFactory<CTrash_S1>::Create(1180.f, 1930.f));

	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(100.f, 1550.f, CAR_TYPE::CAR_1, RIGHT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(500.f, 1550.f, CAR_TYPE::CAR_2, RIGHT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1000.f, 1550.f, CAR_TYPE::CAR_3, RIGHT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1500.f, 1550.f, CAR_TYPE::CAR_5, RIGHT, 100));

	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1000.f, 1475.f, CAR_TYPE::BUS_2, LEFT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(2000.f, 1475.f, CAR_TYPE::BUS_2, LEFT, 200));

	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(400.f, 1020.f, CAR_TYPE::BUS_1, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(800.f, 1020.f, CAR_TYPE::CAR_4, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1200.f, 1020.f, CAR_TYPE::CAR_6, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(2000.f, 1020.f, CAR_TYPE::CAR_4, RIGHT, 200));

	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(400.f, 1630.f, CAR_TYPE::BUS_1, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(800.f, 1630.f, CAR_TYPE::CAR_4, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1200.f, 1630.f, CAR_TYPE::CAR_6, RIGHT, 200));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(2000.f, 1630.f, CAR_TYPE::CAR_4, RIGHT, 200));

	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(100.f, 1240.f, CAR_TYPE::CAR_4, LEFT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(500.f, 1240.f, CAR_TYPE::CAR_1, LEFT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1000.f, 1240.f, CAR_TYPE::CAR_2, LEFT, 100));
	CObjMgr_S1::Get_Instance()->Add_Object(CAR, CAbstractFactory<CCar_S1>::Create_Car(1500.f, 1240.f, CAR_TYPE::CAR_5, LEFT, 100));

	float	g_fSound = 1.f;
	CSoundMgr::Get_Instance()->Initialize();
	CSoundMgr::Get_Instance()->PlayBGM(L"pixel.mp3", g_fSound);
}

void CStage1::Update()
{
	CObjMgr_S1::Get_Instance()->Update();
}

void CStage1::Late_Update()
{
	if (CKeyMgr_S1::Get_Instance()->Key_Down('Q'))
		CSceneMgr::Get_Instance()->Scene_Change(SC_STAGE3);
	
	CObjMgr_S1::Get_Instance()->Late_Update();
}

void CStage1::Render(HDC hDC)
{
	HDC      hMem2DC = CBmpMgr_S1::Get_Instance()->Find_Img(L"bmpMAP");

	int   iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int   iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	BitBlt(hDC, iScrollX, iScrollY, 1975, 2500, hMem2DC, 0, 0, SRCCOPY);

	CObjMgr_S1::Get_Instance()->Render(hDC);
}

void CStage1::Release()
{
	CObjMgr_S1::Get_Instance()->Release();
}