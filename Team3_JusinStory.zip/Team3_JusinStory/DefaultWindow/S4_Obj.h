#pragma once

#include "Define.h"

class S4_Obj
{
public:
	S4_Obj();
	virtual ~S4_Obj();

public:
	INFO&				Get_Info()	{ return m_tInfo; }
	const OBB&			Get_OBB()	const { return m_tOBB; }
	const float			Get_Angle()	const { return m_fAngle; }
	S4_Obj*				Get_Target() { return m_pTarget; }


	void				SetRectPoint(INFO& _Info, float _fCX, float _fCY);
	void				SetPos(D3DXVECTOR3 _vPos) { m_tInfo.vPos = _vPos; }
	void				Set_Target(S4_Obj* _Target) { m_pTarget = _Target; }
	//const

public:
	virtual void		Initialize()	PURE;
	virtual int			Update()		PURE;
	virtual void		Late_Update()   PURE;
	virtual void		Render(HDC hDC)	PURE;
	virtual void		Release()		PURE;

public:
	RENDERID			Get_RenderID() { return m_eRender; }

protected:
	void	Move_Frame();

protected:
	INFO				m_tInfo;
	OBB					m_tOBB;

	D3DXVECTOR3			m_tOriginPos;

	float				m_fSpeed;
	float				m_fAngle;
	float				m_fScaleX;
	float				m_fScaleY;
	FRAME		        m_tFrame;
	TCHAR*				m_pFrameKey;
	DIRECTION	        m_eDir;
	RENDERID			m_eRender;

	S4_Obj*				m_pTarget;
};

