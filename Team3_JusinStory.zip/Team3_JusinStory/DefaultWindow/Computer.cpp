#include "stdafx.h"
#include "Computer.h"

CComputer::CComputer():m_fScaleX(0),m_fScaleY(0)
{
}

CComputer::~CComputer()
{
}

void CComputer::Initialize()
{
	m_fScaleX = 150.f;
	m_fScaleY = 75.f;

	m_tInfo.vPos = { WINCX / 2, WINCY / 2 - 150, 0.f };
}

int CComputer::Update()
{

	return OBJ_NOEVENT;
}

void CComputer::Late_Update()
{
}

void CComputer::Render(HDC hDC)
{
	Rectangle(hDC, m_tInfo.vPos.x - m_fScaleX, m_tInfo.vPos.y - m_fScaleY, m_tInfo.vPos.x + m_fScaleX, m_tInfo.vPos.y + m_fScaleY);
}

void CComputer::Release()
{
}
