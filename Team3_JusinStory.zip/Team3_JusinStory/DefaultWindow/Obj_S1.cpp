#include "stdafx.h"
#include "Obj_S1.h"
#include "ScrollMgr_S1.h"

CObj_S1::CObj_S1() : m_fSpeed(0.f), m_bDead(false), m_eDIr(DIR_END), m_dwtime((DWORD)GetTickCount64())
{
	ZeroMemory(&m_tInfo, sizeof(INFO));
	D3DXMatrixIdentity(&m_tInfo.matWorld);
}

CObj_S1::~CObj_S1()
{
}


void CObj_S1::Move_Frame()
{
	if (m_tFrame.dwTime + m_tFrame.dwSpeed < (DWORD)GetTickCount64())
	{
		++m_tFrame.iFrameStart;

		if (m_tFrame.iFrameStart > m_tFrame.iFrameEnd)
			m_tFrame.iFrameStart = 0;

		m_tFrame.dwTime = (DWORD)GetTickCount64();
	}
}


void	CObj_S1::ColliderRender(HDC hDC, D3DXVECTOR3 _LT, D3DXVECTOR3 _RT, D3DXVECTOR3 _RB, D3DXVECTOR3 _LB)
{
	int		iScrollX = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollX();
	int		iScrollY = (int)CScrollMgr_S1::Get_Instance()->Get_ScrollY();

	HBRUSH myBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
	HBRUSH oldBrush = (HBRUSH)SelectObject(hDC, myBrush);

	HPEN myPen = CreatePen(PS_SOLID, 2, RGB(80, 220, 100));
	HPEN OldPen = (HPEN)SelectObject(hDC, myPen);

	MoveToEx(hDC, _LT.x + iScrollX, _LT.y + iScrollY, nullptr);
	LineTo(hDC, _RT.x + iScrollX, _RT.y + iScrollY);
	LineTo(hDC, _RB.x + iScrollX, _RB.y + iScrollY);
	LineTo(hDC, _LB.x + iScrollX, _LB.y + iScrollY);
	LineTo(hDC, _LT.x + iScrollX, _LT.y + iScrollY);

	SelectObject(hDC, oldBrush);
	DeleteObject(myBrush);

	SelectObject(hDC, OldPen);
	DeleteObject(myPen);
}