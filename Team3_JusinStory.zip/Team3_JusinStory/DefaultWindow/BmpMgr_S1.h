#pragma once
#include "BitMap_S1.h"

class CBmpMgr_S1
{
private:
	CBmpMgr_S1();
	~CBmpMgr_S1();

public:
	void		Insert_Bmp(const TCHAR* pFilePath, const TCHAR* pImgKey);
	HDC			Find_Img(const TCHAR* pImgKey);
	void		Release();

public:
	static CBmpMgr_S1* Get_Instance()
	{
		if (!m_pInstance)
		{
			m_pInstance = new CBmpMgr_S1;
		}

		return m_pInstance;
	}
	static void		Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}

private:
	static CBmpMgr_S1* m_pInstance;
	map<const TCHAR*, CBitMap_S1*>			m_mapBit;

};

