#include "stdafx.h"
#include "ObjMgr_S1.h"
#include "CollisionMgr_S1.h"
#include "Player_S1.h"
#include "Trash_S1.h"


CObjMgr_S1* CObjMgr_S1::m_pInstance = nullptr;

CObjMgr_S1::CObjMgr_S1()
{
}


CObjMgr_S1::~CObjMgr_S1()
{
    Release();
}

//CObj_S1* CObjMgr_S1::Get_Target(OBJID eID, CObj_S1* pInstance)
//{

   //if (m_ObjList[eID].empty())
   //   return nullptr;

   //CObj_S1* pTarget = nullptr;
   //float   fDistance = 0.f;CObjMgr_S1

   //for (auto& iter : m_ObjList[eID])
   //{
   //   if (iter->Get_Dead())
   //      continue;

   //   float   fWidth = iter->Get_Info().fX - pInstance->Get_Info().fX;
   //   float   fHeight = iter->Get_Info().fY - pInstance->Get_Info().fY;

   //   float   fDiagonal = sqrtf(fWidth * fWidth + fHeight * fHeight);

   //   // ������ ���
   //   if ((!pTarget) || (fDistance > fDiagonal))
   //   {
   //      pTarget = iter;
   //      fDistance = fDiagonal;
   //   }
   //}

   //return pTarget;


//}

void CObjMgr_S1::Add_Object(OBJID eID, CObj_S1* pInstance)
{
    if (OBJID_END <= eID || nullptr == pInstance)
        return;

    m_ObjList[eID].push_back(pInstance);
}

int CObjMgr_S1::Update()
{
    for (size_t i = 0; i < OBJID_END; ++i)
    {
        for (auto iter = m_ObjList[i].begin();
            iter != m_ObjList[i].end(); )
        {
            int iResult = (*iter)->Update();

            if (OBJ_DEAD == iResult)
            {
                Safe_Delete<CObj_S1*>(*iter);
                iter = m_ObjList[i].erase(iter);
            }
            else
                ++iter;
        }
    }

    return 0;
}

void CObjMgr_S1::Late_Update()
{
    //for (size_t i = 0; i < OBJID_END; ++i)
    //{
    //   for (auto& iter : m_ObjList[i])
    //   {
    //      iter->Late_Update();

    //      if (m_ObjList[i].empty())
    //         break;

    //      RENDERID eRender = iter->Get_RenderID();
    //      m_RenderList[eRender].push_back(iter);
    //   }

    //}

    D3DXVECTOR3 collisionNormal;
    float minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2;

    if (CCollisionMgr_S1::PolygonCollision(
        CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(),
        CObjMgr_S1::Get_Instance()->Get_OBJLIST(TRASH).front()->Get_vPoint(),
        collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2));
    {
        CCollisionMgr_S1::ResolveCollision(
            CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(),
            CObjMgr_S1::Get_Instance()->Get_OBJLIST(TRASH).front()->Get_vPoint(),
            collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2
        );
    }

    //if (!CObjMgr_S1::Get_Instance()->Get_OBJLIST(CAR).empty()) {
    //   for (auto& iter = CObjMgr_S1::Get_Instance()->Get_OBJLIST(CAR).begin();
    //      iter != CObjMgr_S1::Get_Instance()->Get_OBJLIST(CAR).end(); ) {

    //      if (CCollisionMgr_S1::PolygonCollision(
    //         CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(), (*iter)->Get_vPoint(),
    //         collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2))
    //      {
    //         CCollisionMgr_S1::ResolveCollision(
    //         CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(), (*iter)->Get_vPoint(),
    //         collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2);
    //      }
    //      else { ++iter; }
    //   }
    //}

    if (!CObjMgr_S1::Get_Instance()->Get_OBJLIST(CAR).empty()) {
        list<CObj_S1*> objectsToBeMoved;
        list<CObj_S1*> CAR_List = CObjMgr_S1::Get_Instance()->Get_OBJLIST(CAR);
        //���� ���� ������

        for (auto& iter = CAR_List.begin(); iter != CAR_List.end(); ++iter) {

            if (CCollisionMgr_S1::PolygonCollision(
                CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(), (*iter)->Get_vPoint(),
                collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2))
            {
                // �浹 ó���� ���� �ʰ�, �̵��ؾ��� ��ü���� ����Ʈ�� �߰�
                objectsToBeMoved.push_back(*iter);
            }
        }

        // �浹�� �Ͼ ��ü���� ���� �̵�
        for (auto& obj : objectsToBeMoved) {
            CCollisionMgr_S1::ResolveCollision(
                CObjMgr_S1::Get_Instance()->Get_Player()->Get_vPoint(), obj->Get_vPoint(),
                collisionNormal, minoverlap, _collisionEdgeIndex1, _collisionEdgeIndex2);
        }
    }


    /* if (CCollisionMgr_S1::PolygonCollision(
    dynamic_cast<CPlayer_S1*>(m_pPlayer)->Get_vPoint(),
    dynamic_cast<CTrash_S1*>(�ǹ�)->Get_vPoint()))
    { //�ǹ� �浹 ���� �и���   } */

    /* if (CCollisionMgr_S1::PolygonCollision(
    dynamic_cast<CPlayer_S1*>(m_pPlayer)->Get_vPoint(),
    dynamic_cast<CTrash_S1*>(�и����� �ڽ�)->Get_vPoint()))
    { //�浹 ���� �з�����   } */




    for (size_t i = 0; i < OBJID_END; ++i)
    {
        for (auto& iter : m_ObjList[i])
            iter->Late_Update();
    }

}

void CObjMgr_S1::Render(HDC hDC)
{
    //for (size_t i = 0; i < RENDER_END; ++i)
    //{
    //   m_RenderList[i].sort([](CObj_S1* pDst, CObj_S1* pSrc) 
    //      { return pDst->Get_Info().vPos.y < pSrc->Get_Info().vPos.y; });

    //   for (auto& iter : m_RenderList[i])
    //      iter->Render(hDC);

    //   m_RenderList[i].clear();
    //}

    for (size_t i = 0; i < OBJID_END; ++i)
    {
        for (auto& iter : m_ObjList[i])
            iter->Render(hDC);
    }

}

void CObjMgr_S1::Release()
{
    for (size_t i = 0; i < OBJID_END; ++i)
    {
        for_each(m_ObjList[i].begin(), m_ObjList[i].end(), Safe_Delete<CObj_S1*>);
        m_ObjList[i].clear();
    }

    for (size_t i = 0; i < RENDER_END; ++i)
        m_RenderList[i].clear();

}

void CObjMgr_S1::Delete_ID(OBJID eID)
{
    for (auto& iter : m_ObjList[eID])
        Safe_Delete(iter);

    m_ObjList[eID].clear();
}