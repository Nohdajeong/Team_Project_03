#pragma once
#include "S4_Obj.h"
class S4_CAnswerCube :
    public S4_Obj
{
public:
             S4_CAnswerCube();
    virtual ~S4_CAnswerCube();

public:
    virtual void Initialize() override;
    virtual int  Update() override;
    virtual void Late_Update() override;
    virtual void Render(HDC hDC) override;
    virtual void Release() override;

};

