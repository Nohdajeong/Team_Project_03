#pragma once
#include "Obj_S3.h"

class CAwake_S3 : public CObj_S3
{
public:
	enum STATE { IDLE, STATE_END };

public:
	CAwake_S3();
	virtual ~CAwake_S3();

public:
	virtual void Initialize(void) override;
	virtual int Update(void) override;
	virtual void Late_Update(void) override;
	virtual void Render(HDC hDC) override;
	virtual void Release(void) override;

private:
	CObj_S3*	Sleep(void);

private:
	STATE				m_eCurState;
	STATE				m_ePreState;
	DWORD				m_dwTime;
};


