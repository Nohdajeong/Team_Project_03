#pragma once
#include "S4_Obj.h"

template<typename T>
class S4_CAbstractFactory
{
public:
	S4_CAbstractFactory() {}
	~S4_CAbstractFactory() {}

public:
	static S4_Obj* Create()
	{
		S4_Obj* pObj = new T;
		pObj->Initialize();

		return pObj;
	}

	static S4_Obj* Create(float _fX, float _fY)
	{
		S4_Obj* pObj = new T;
		pObj->Initialize();
		pObj->Set_Pos(_fX, _fY);

		return pObj;
	}

};

